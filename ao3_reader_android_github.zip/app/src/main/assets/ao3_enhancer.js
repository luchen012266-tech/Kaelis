(function() {
  if (window.__ao3EnhancerV50Loaded) {
    if (window.__ao3ApplyAll) window.__ao3ApplyAll();
    return;
  }
  window.__ao3EnhancerV50Loaded = true;

  const DEFAULT_STORE = {
    ui: {
      fontSize: 15,
      fontFamily: "system",
      hue: 262,
      sat: 28,
      light: 90,
      bgOpacity: 88,
      bgImage: ""
    },
    reader: {
      fontSize: 19,
      fontFamily: "system",
      hue: 262,
      sat: 25,
      light: 92,
      bgOpacity: 92,
      bgImage: "",
      readingMode: "scroll" // "scroll" or "page"
    },
    zhTranslate: true
  };

  let store = JSON.parse(JSON.stringify(DEFAULT_STORE));
  try {
    const saved = localStorage.getItem("__kaelis_dual_cfg_v5");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.ui) Object.assign(store.ui, parsed.ui);
      if (parsed.reader) Object.assign(store.reader, parsed.reader);
    } else {
      // Migrate from v3/v4 if present
      const old = localStorage.getItem("__ao3_custom_reader_cfg_v3");
      if (old) {
        const p = JSON.parse(old);
        store.ui.hue = p.hue ?? 262;
        store.ui.sat = p.sat ?? 28;
        store.ui.light = p.light ?? 90;
        store.reader.fontSize = p.fontSize ?? 19;
        store.reader.fontFamily = p.fontFamily ?? "system";
        store.reader.hue = p.hue ?? 262;
        store.reader.sat = p.sat ?? 28;
        store.reader.light = p.light ?? 90;
        store.reader.readingMode = p.readingMode ?? "scroll";
      }
    }
  } catch (e) {}

  try {
    const bgUi = localStorage.getItem("__kaelis_bg_ui_v5") || localStorage.getItem("__ao3_custom_reader_bg_v1");
    if (bgUi) store.ui.bgImage = bgUi;
    const bgReader = localStorage.getItem("__kaelis_bg_reader_v5");
    if (bgReader) store.reader.bgImage = bgReader;
  } catch (e) {}

  function saveStore() {
    try {
      const copy = {
        ui: Object.assign({}, store.ui, { bgImage: "" }),
        reader: Object.assign({}, store.reader, { bgImage: "" }),
        zhTranslate: store.zhTranslate
      };
      localStorage.setItem("__kaelis_dual_cfg_v5", JSON.stringify(copy));
      if (store.ui.bgImage) localStorage.setItem("__kaelis_bg_ui_v5", store.ui.bgImage);
      else localStorage.removeItem("__kaelis_bg_ui_v5");
      if (store.reader.bgImage) localStorage.setItem("__kaelis_bg_reader_v5", store.reader.bgImage);
      else localStorage.removeItem("__kaelis_bg_reader_v5");
    } catch (e) {}
  }

  function isReadingWorkPage() {
    return !!(document.getElementById("workskin") || document.getElementById("chapters"));
  }

  function getActiveProfile() {
    return isReadingWorkPage() ? store.reader : store.ui;
  }

  const PRESETS = [
    { name: "雾紫", h: 262, s: 28, l: 90 },
    { name: "丁香", h: 258, s: 45, l: 84 },
    { name: "烟粉", h: 310, s: 26, l: 88 },
    { name: "暮山紫", h: 256, s: 22, l: 76 },
    { name: "云水蓝", h: 220, s: 16, l: 92 },
    { name: "羊皮纸", h: 42, s: 38, l: 93 },
    { name: "夜间黑", h: 240, s: 14, l: 15 }
  ];

  const ZH_DICT = {
    "Fandoms": "同人圈",
    "Browse": "浏览",
    "Search": "搜索",
    "About": "关于",
    "Log In": "登录",
    "Log Out": "退出",
    "Post": "发布",
    "New Work": "发布新作",
    "Import Work": "导入作品",
    "My Dashboard": "个人主页",
    "Dashboard": "主页",
    "Profile": "个人资料",
    "Preferences": "偏好设置",
    "Skins": "网站皮肤",
    "Works": "作品",
    "Drafts": "草稿",
    "Series": "系列",
    "Bookmarks": "收藏书签",
    "Collections": "合集",
    "Inbox": "收件箱",
    "Statistics": "数据统计",
    "History": "阅读历史",
    "Subscriptions": "我的订阅",
    "Find your favorites": "探索你喜欢的同人圈",
    "All Fandoms": "全部同人圈",
    "Anime & Manga": "动漫与漫画 (ACG)",
    "Books & Literature": "书籍与文学",
    "Cartoons & Comics & Graphic Novels": "卡通、美漫与绘本",
    "Celebrities & Real People": "真人影视与明星 (RPS)",
    "Movies": "电影专区",
    "Music & Bands": "音乐与乐队",
    "Other Media": "其他衍生媒体",
    "Theater": "戏剧与音乐剧",
    "TV Shows": "电视剧集",
    "Video Games": "电子游戏",
    "Uncategorized Fandoms": "未分类同人圈",
    "News": "站内公告",
    "All News": "全部公告",
    "Search Results": "搜索结果",
    "Edit Your Search": "修改搜索条件",
    "Sort and Filter": "排序与筛选",
    "Sort by": "排序方式",
    "Best Match": "最佳匹配",
    "Author": "作者",
    "Title": "标题",
    "Date Posted": "发布日期",
    "Date Updated": "更新日期",
    "Word Count": "字数统计",
    "Hits": "点击量",
    "Kudos": "点赞数",
    "Comments": "评论数",
    "Bookmarks:": "收藏：",
    "Collections:": "合集：",
    "Comments:": "评论：",
    "Kudos:": "点赞：",
    "Hits:": "点击：",
    "Words:": "字数：",
    "Chapters:": "章节：",
    "Language:": "语言：",
    "Series:": "系列：",
    "Published:": "发布：",
    "Updated:": "更新：",
    "Completed:": "完结：",
    "Status:": "状态：",
    "Rating": "分级",
    "Rating:": "分级：",
    "Archive Warning": "归档警告",
    "Archive Warnings": "归档警告",
    "Archive Warning:": "归档警告：",
    "Archive Warnings:": "归档警告：",
    "Category": "性向分类",
    "Categories": "性向分类",
    "Category:": "性向分类：",
    "Categories:": "性向分类：",
    "Fandom": "原作圈",
    "Fandom:": "原作圈：",
    "Fandoms:": "原作圈：",
    "Relationship": "配对/CP",
    "Relationships": "配对/CP",
    "Relationship:": "配对/CP：",
    "Relationships:": "配对/CP：",
    "Character": "角色",
    "Characters": "角色",
    "Character:": "角色：",
    "Characters:": "角色：",
    "Additional Tags": "附加标签",
    "Additional Tags:": "附加标签：",
    "Stats": "数据统计",
    "Stats:": "统计：",
    "Summary": "作品简介",
    "Summary:": "作品简介",
    "Notes": "作者的话",
    "Notes:": "作者的话",
    "Work Text": "正文内容",
    "Work Text:": "正文内容",
    "Chapter Text": "",
    "Entire Work": "全文阅读",
    "Chapter by Chapter": "分章阅读",
    "Chapter Index": "章节目录",
    "Next Chapter →": "下一章 →",
    "← Previous Chapter": "← 上一章",
    "Kudos ♥": "♥ 点赞",
    "Bookmark": "收藏",
    "Subscribe": "订阅",
    "Download": "下载",
    "Share": "分享",
    "Top": "返回顶部",
    "No Archive Warnings Apply": "无归档警告",
    "Creator Chose Not To Use Archive Warnings": "作者未标注归档警告",
    "Graphic Depictions Of Violence": "含暴力描写",
    "Major Character Death": "主要角色死亡",
    "Underage": "未成年相关警告",
    "Underage Sex": "未成年相关警告",
    "Rape/Non-Con": "非自愿警告",
    "General Audiences": "全年龄 (G)",
    "Teen And Up Audiences": "青少年及以上 (T)",
    "Mature": "成熟级 (M)",
    "Explicit": "限制级 (E)",
    "Not Rated": "未分级"
  };

  const MONTH_MAP = {
    jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06",
    jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12"
  };

  function translateTagText(str) {
    const t = (str || "").trim();
    return ZH_DICT[t] !== undefined ? ZH_DICT[t] : t;
  }

  function convertDateString(str) {
    if (!str) return "";
    return str.replace(/\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s*(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{4})(?:\s+(\d{1,2}:\d{2})\s*([AP]M)?\s*(?:UTC|EST|EDT|PST)?)?/gi, function(_, d, m, y, time, ampm) {
      const mm = MONTH_MAP[m.toLowerCase().slice(0, 3)] || "01";
      const dd = String(d).padStart(2, "0");
      if (time) {
        let [hh, min] = time.split(":");
        let hNum = parseInt(hh, 10);
        if (ampm && ampm.toUpperCase() === "PM" && hNum < 12) hNum += 12;
        if (ampm && ampm.toUpperCase() === "AM" && hNum === 12) hNum = 0;
        return `${y}-${mm}-${dd} ${String(hNum).padStart(2, "0")}:${min}`;
      }
      return `${y}-${mm}-${dd}`;
    }).trim();
  }

  function getFontStack(key) {
    if (key === "song") return "'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', 'SimSun', serif";
    if (key === "kai") return "'LXGW WenKai', 'Kaiti SC', 'STKaiti', 'KaiTi', serif";
    if (key === "hei") return "'PingFang SC', 'HarmonyOS Sans SC', 'Microsoft YaHei', sans-serif";
    return "-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Segoe UI', Roboto, sans-serif";
  }

  function ensureViewportMeta() {
    if (!document.head) return;
    let vp = document.querySelector('meta[name="viewport"]');
    if (!vp) {
      vp = document.createElement("meta");
      vp.name = "viewport";
      document.head.appendChild(vp);
    }
    vp.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no";
  }

  function injectStyles() {
    if (!document.head) return;
    let styleEl = document.getElementById("__ao3_custom_style_v50");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "__ao3_custom_style_v50";
      document.head.appendChild(styleEl);
    }

    const active = getActiveProfile();
    const isDark = active.light < 36;
    const textColor = isDark ? "#f0ecf8" : "#2b2538";
    const subTextColor = isDark ? "#aba2be" : "#746b86";
    const accentColor = `hsl(${active.hue}, ${Math.min(active.sat + 30, 72)}%, ${isDark ? 72 : 43}%)`;
    const accentSoft = isDark
      ? `hsla(${active.hue}, ${Math.min(active.sat + 25, 65)}%, 62%, 0.22)`
      : `hsla(${active.hue}, ${Math.min(active.sat + 25, 65)}%, 48%, 0.12)`;
    const pageBgHsl = `hsl(${active.hue}, ${active.sat}%, ${active.light}%)`;
    const cardAlpha = Math.max(0.25, Math.min(0.98, active.bgOpacity / 100));
    const cardBg = isDark
      ? `rgba(34, 30, 44, ${cardAlpha})`
      : `rgba(255, 255, 255, ${cardAlpha})`;
    const pillBg = isDark
      ? `rgba(48, 42, 62, 0.90)`
      : `rgba(255, 255, 255, 0.92)`;
    const borderCol = isDark
      ? "rgba(255, 255, 255, 0.12)"
      : "rgba(165, 152, 195, 0.22)";

    const uiFontStack = getFontStack(store.ui.fontFamily);
    const readerFontStack = getFontStack(store.reader.fontFamily);
    const uiSize = store.ui.fontSize;
    const readerSize = store.reader.fontSize;

    // Notice: Zero backdrop-filter on scrolling cards/modules for buttery-smooth 60/120fps scrolling!
    styleEl.textContent = `
      :root {
        --ao3-bg: ${pageBgHsl};
        --ao3-card-bg: ${cardBg};
        --ao3-pill-bg: ${pillBg};
        --ao3-border: ${borderCol};
        --ao3-text: ${textColor};
        --ao3-subtext: ${subTextColor};
        --ao3-accent: ${accentColor};
        --ao3-accent-soft: ${accentSoft};
        --ui-font: ${uiFontStack};
        --ui-size: ${uiSize}px;
        --reader-font: ${readerFontStack};
        --reader-size: ${readerSize}px;
      }

      *, *:focus, *:active, button, input, select, a {
        outline: none !important;
        -webkit-tap-highlight-color: transparent !important;
      }

      #header, #footer {
        display: none !important;
      }

      html, body, #outer, #inner {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ui-font) !important;
        font-size: var(--ui-size) !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        overflow-x: hidden !important;
        -webkit-overflow-scrolling: touch !important;
      }

      #main {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ui-font) !important;
        font-size: var(--ui-size) !important;
        padding: 6px 12px 80px 12px !important;
        margin: 0 auto !important;
        max-width: 680px !important;
        box-sizing: border-box !important;
      }

      body.__ao3_paged_active > *:not(#__ao3_bg_layer):not(#__ao3_bg_overlay):not(#__ao3_paged_reader):not(#__ao3_settings_modal) {
        display: none !important;
      }

      #__ao3_bg_layer {
        position: fixed !important;
        inset: 0 !important;
        z-index: -2 !important;
        background-color: var(--ao3-bg) !important;
        background-image: ${active.bgImage ? `url("${active.bgImage}")` : "none"} !important;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
        transform: translateZ(0) !important;
        will-change: transform !important;
      }

      #__ao3_bg_overlay {
        position: fixed !important;
        inset: 0 !important;
        z-index: -1 !important;
        background-color: var(--ao3-bg) !important;
        opacity: ${active.bgImage ? (100 - active.bgOpacity) / 100 : 1} !important;
        pointer-events: none !important;
      }

      h1, h2, h3, h4, h5, h6,
      .heading, .splash .module h3,
      .splash .browse li a:before,
      span.symbol, .question {
        color: var(--ao3-accent) !important;
        border-bottom-color: var(--ao3-border) !important;
        font-family: var(--ui-font) !important;
      }

      h2.heading {
        font-size: calc(var(--ui-size) * 1.12) !important;
        margin: 6px 4px 10px 4px !important;
      }

      a, a:link, a:visited, a:hover, a:active, abbr {
        color: var(--ao3-text) !important;
        border-bottom: none !important;
        text-decoration: none !important;
        background: transparent !important;
      }

      /* Home Page (.splash) lightweight smooth cards (NO backdrop-filter lag!) */
      .splash .module, .splash .browse, .splash .news {
        background: var(--ao3-card-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 22px !important;
        padding: 18px 16px !important;
        margin: 0 0 14px 0 !important;
        box-shadow: 0 4px 14px rgba(42, 32, 68, 0.04) !important;
        width: 100% !important;
        float: none !important;
        box-sizing: border-box !important;
      }

      .splash .browse p {
        font-size: calc(var(--ui-size) * 0.90) !important;
        line-height: 1.55 !important;
        color: var(--ao3-subtext) !important;
        margin: 6px 0 12px 0 !important;
      }

      .splash .browse ul {
        display: grid !important;
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 10px !important;
        padding: 0 !important;
        margin: 10px 0 0 0 !important;
      }

      .splash .browse li {
        width: 100% !important;
        float: none !important;
        margin: 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .splash .browse li a {
        display: flex !important;
        align-items: center !important;
        min-height: 44px !important;
        padding: 10px 12px !important;
        background: var(--ao3-pill-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 14px !important;
        font-size: calc(var(--ui-size) * 0.88) !important;
        font-weight: 600 !important;
        line-height: 1.35 !important;
        color: var(--ao3-text) !important;
        box-sizing: border-box !important;
      }

      /* Search Results List Reset */
      ol.work.index.group, ul.index.group, ol.bookmark.index.group {
        padding: 0 !important;
        margin: 0 !important;
        list-style: none !important;
      }

      /* Uniform, lightweight Search Cards (NO backdrop-filter lag!) */
      li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group {
        background: var(--ao3-card-bg) !important;
        border-radius: 22px !important;
        border: 1px solid var(--ao3-border) !important;
        padding: 16px 18px 14px 18px !important;
        margin: 12px 0 !important;
        box-shadow: 0 4px 14px rgba(42, 32, 68, 0.04) !important;
        position: relative !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
      }

      li.blurb dl.stats, dl.stats {
        background: transparent !important;
        border: none !important;
        border-top: 1px solid var(--ao3-border) !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        padding: 10px 0 0 0 !important;
        margin: 10px 0 0 0 !important;
      }

      /* Work Reading View (#workskin, #chapters) uses independent --reader-font and --reader-size! */
      dl.work.meta.group {
        background: var(--ao3-card-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 20px !important;
        padding: 14px 16px !important;
        margin: 0 0 12px 0 !important;
        box-shadow: none !important;
        font-family: var(--ui-font) !important;
        font-size: var(--ui-size) !important;
      }

      dl.work.meta.group:not(.__ao3_meta_open) > dt,
      dl.work.meta.group:not(.__ao3_meta_open) > dd {
        display: none !important;
      }

      #workskin {
        background: var(--ao3-card-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 24px !important;
        padding: 20px 18px !important;
        margin: 0 !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        box-shadow: 0 6px 20px rgba(42, 32, 68, 0.05) !important;
        font-family: var(--reader-font) !important;
        font-size: var(--reader-size) !important;
      }

      #workskin h2.title.heading {
        font-family: var(--reader-font) !important;
        font-size: calc(var(--reader-size) * 1.22) !important;
        font-weight: 800 !important;
        line-height: 1.4 !important;
        margin-bottom: 6px !important;
      }

      #workskin .preface,
      #workskin .preface .module,
      #workskin .preface blockquote.userstuff {
        margin: 8px 0 !important;
        padding: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        border: none !important;
        font-family: var(--reader-font) !important;
        font-size: var(--reader-size) !important;
      }

      #chapters h3.landmark.heading {
        display: none !important;
      }

      #workskin .preface h3.title {
        border-bottom: none !important;
        font-size: calc(var(--reader-size) * 0.90) !important;
        color: var(--ao3-accent) !important;
        margin-bottom: 4px !important;
      }

      #chapters, #chapters .userstuff, #workskin div.userstuff {
        font-family: var(--reader-font) !important;
        font-size: var(--reader-size) !important;
        line-height: 1.9 !important;
        color: var(--ao3-text) !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      #chapters p, #workskin div.userstuff p {
        font-family: var(--reader-font) !important;
        font-size: var(--reader-size) !important;
        line-height: 1.9 !important;
        margin: 0 0 1.1em 0 !important;
        text-align: justify !important;
      }

      ul.work.navigation.actions, ul.actions, p.actions, span.actions {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 6px !important;
        margin: 8px 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .actions a, .actions input[type="submit"], .actions button,
      input[type="submit"], button.action {
        background: var(--ao3-pill-bg) !important;
        color: var(--ao3-text) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 12px !important;
        padding: 7px 14px !important;
        font-size: calc(var(--ui-size) * 0.84) !important;
        font-weight: 600 !important;
        box-shadow: none !important;
      }

      /* Settings Modal Styling */
      #__ao3_settings_modal .__ao3_color_dot {
        width: 36px !important;
        height: 36px !important;
        min-width: 36px !important;
        max-width: 36px !important;
        min-height: 36px !important;
        max-height: 36px !important;
        padding: 0 !important;
        margin: 0 !important;
        border-radius: 50% !important;
        aspect-ratio: 1 / 1 !important;
        flex: 0 0 36px !important;
        display: inline-block !important;
        box-sizing: border-box !important;
        cursor: pointer !important;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08) !important;
      }

      #__ao3_settings_modal input[type="range"] {
        -webkit-appearance: none !important;
        appearance: none !important;
        height: 10px !important;
        border-radius: 999px !important;
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      #__ao3_settings_modal #__ao3_hue {
        background: linear-gradient(to right, #e57373, #ffb74d, #fff176, #81c784, #64b5f6, #9575cd, #f06292) !important;
      }

      #__ao3_settings_modal #__ao3_sat {
        background: linear-gradient(to right, #e6e4ea, #b39ddb) !important;
      }

      #__ao3_settings_modal #__ao3_light {
        background: linear-gradient(to right, #2c2638, #b39ddb, #ffffff) !important;
      }

      #__ao3_settings_modal #__ao3_opacity,
      #__ao3_settings_modal #__ao3_fs_range {
        background: #e2dde9 !important;
      }

      #__ao3_settings_modal input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none !important;
        appearance: none !important;
        width: 24px !important;
        height: 24px !important;
        border-radius: 50% !important;
        background: #ffffff !important;
        border: 2.5px solid #6b5e82 !important;
        box-shadow: 0 2px 6px rgba(0,0,0,0.18) !important;
      }
    `;
  }

  function ensureBgLayers() {
    if (!document.body) return;
    if (!document.getElementById("__ao3_bg_layer")) {
      const bg = document.createElement("div");
      bg.id = "__ao3_bg_layer";
      const ov = document.createElement("div");
      ov.id = "__ao3_bg_overlay";
      document.body.prepend(ov);
      document.body.prepend(bg);
    }
  }

  function getLoggedInUser() {
    const userLink = document.querySelector('#greeting a[href^="/users/"]');
    if (userLink && userLink.getAttribute("href")) {
      const parts = userLink.getAttribute("href").split("/");
      if (parts[2]) return parts[2].trim();
    }
    const greeting = document.querySelector("#greeting p.icon a, #greeting .user a");
    if (greeting && greeting.textContent) {
      return greeting.textContent
        .replace(/^(你好，|Hi,)\s*/i, "")
        .replace(/!$/, "")
        .trim();
    }
    return "";
  }

  // Idempotent Header Builder: creates once per page load so it NEVER causes reflow lag!
  function buildCustomHeader() {
    if (!document.body) return;
    let header = document.getElementById("__ao3_custom_header");
    if (header) {
      const mb = header.querySelector("#__ao3_mode_btn");
      if (mb) mb.textContent = store.reader.readingMode === "page" ? "翻页模式" : "滑动模式";
      return;
    }

    const username = getLoggedInUser();
    header = document.createElement("div");
    header.id = "__ao3_custom_header";
    header.style.cssText = "max-width:680px;margin:0 auto;padding:12px 12px 4px 12px;box-sizing:border-box;position:relative;z-index:9980;";

    header.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;">
        <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1;">
          <button id="__ao3_btn_menu" style="width:42px;height:42px;flex:0 0 42px;border-radius:14px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:18px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0;">
            ☰
          </button>
          <div style="min-width:0;flex:1;">
            <div style="font-size:18px;font-weight:800;color:var(--ao3-text);line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              Kaelis
            </div>
            <div style="font-size:12px;color:var(--ao3-subtext);line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;">
              ${username ? `@${username} · v5.0` : "AO3 专属阅读 · v5.0"}
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
          <button id="__ao3_mode_btn" style="height:40px;padding:0 14px;border-radius:999px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:13px;font-weight:700;white-space:nowrap;">
            ${store.reader.readingMode === "page" ? "翻页模式" : "滑动模式"}
          </button>
          <button id="__ao3_open_settings" title="设置" style="width:42px;height:42px;flex:0 0 42px;padding:0;border-radius:14px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);display:flex;align-items:center;justify-content:center;">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18.37 2.63 14 7l-1.59-1.59a2 2 0 0 0-2.82 0L8 7l9 9 1.59-1.59a2 2 0 0 0 0-2.82L17 10l4.37-4.37a2.12 2.12 0 1 0-3-3Z"/>
              <path d="M9 8c-2 3-4 3.5-7 4l8 10c2-1 6-5 6-7"/>
              <path d="M14.5 17.5 3.5 15"/>
            </svg>
          </button>
        </div>
      </div>

      <div id="__ao3_nav_drawer" style="background:var(--ao3-card-bg);border:1px solid var(--ao3-border);border-radius:20px;padding:12px;margin-bottom:6px;box-sizing:border-box;">
        <form action="/works/search" method="get" style="display:flex;gap:8px;margin:0 0 10px 0;">
          <input type="text" name="work_search[query]" placeholder="搜索同人圈、角色、CP或关键词..." style="flex:1;min-width:0;height:40px;padding:0 14px;border-radius:12px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:14px;" />
          <button type="submit" style="height:40px;padding:0 18px;border-radius:12px;border:none;background:var(--ao3-accent);color:#fff;font-size:13.5px;font-weight:700;flex-shrink:0;">
            搜索
          </button>
        </form>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;font-size:12.5px;font-weight:600;">
          <a href="/" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🏠 首页</a>
          <a href="/media" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">✨ 同人圈</a>
          ${username ? `<a href="/users/${username}/bookmarks" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">❤️ 收藏</a>` : `<a href="/works/search" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🔍 筛选</a>`}
          ${username ? `<a href="/users/${username}/readings" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🕒 历史</a>` : `<a href="/users/login" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🔑 登录</a>`}
        </div>
      </div>
    `;

    document.body.prepend(header);

    const navDrawer = header.querySelector("#__ao3_nav_drawer");
    if (isReadingWorkPage()) {
      navDrawer.style.display = "none";
    }

    header.querySelector("#__ao3_btn_menu").addEventListener("click", () => {
      navDrawer.style.display = navDrawer.style.display === "none" ? "block" : "none";
    });

    header.querySelector("#__ao3_mode_btn").addEventListener("click", function() {
      store.reader.readingMode = store.reader.readingMode === "scroll" ? "page" : "scroll";
      this.textContent = store.reader.readingMode === "page" ? "翻页模式" : "滑动模式";
      saveStore();
      applyAll();
    });

    header.querySelector("#__ao3_open_settings").addEventListener("click", () => {
      if (window.__kaelisOpenSettingsModal) {
        window.__kaelisOpenSettingsModal(isReadingWorkPage() ? "reader" : "ui");
      }
    });
  }

  // ==================== UNIFORM-SIZE CARDS WITH DEDICATED LARGE TITLE LINE (v5.0) ====================
  function rebuildBlurbCardsUniform() {
    const blurbs = document.querySelectorAll("li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group");
    blurbs.forEach(card => {
      if (card.dataset.kaelisRebuilt === "1") return;
      if (!card.querySelector("dl.stats") && document.readyState === "loading") return;

      const titleLink = card.querySelector("h4.heading a:first-child");
      if (!titleLink) return;
      const titleText = titleLink.textContent.trim();
      const workUrl = titleLink.getAttribute("href") || "#";

      const authorLinks = card.querySelectorAll('h4.heading a[rel="author"]');
      let authorHtml = "Anonymous";
      if (authorLinks.length > 0) {
        authorHtml = Array.from(authorLinks).map(a => `<a href="${a.getAttribute("href")}" style="font-weight:600;color:var(--ao3-subtext);">${a.textContent.trim()}</a>`).join(", ");
      }

      const fandomLinks = card.querySelectorAll("h5.fandoms.heading a");
      const fandomText = Array.from(fandomLinks).map(a => a.textContent.trim()).join(" / ") || "";

      const dateEl = card.querySelector("p.datetime");
      const dateStr = dateEl ? convertDateString(dateEl.textContent) : "";

      const relEls = card.querySelectorAll("ul.tags li.relationships a");
      const cpBadgeText = relEls.length > 0 ? relEls[0].textContent.trim() : "";

      const allTagEls = card.querySelectorAll("ul.tags li a");
      const allTags = [];
      allTagEls.forEach(a => {
        const t = translateTagText(a.textContent);
        if (!t) return;
        const href = a.getAttribute("href") || "#";
        const isRel = a.parentElement && a.parentElement.classList.contains("relationships");
        allTags.push({ text: t, href: href, isRel: isRel });
      });

      const summaryEl = card.querySelector("blockquote.userstuff.summary");
      let summaryFullHtml = "";
      let summaryPlainText = "";
      let summaryParaCount = 0;
      if (summaryEl) {
        summaryParaCount = summaryEl.querySelectorAll("p, br").length;
        summaryPlainText = (summaryEl.textContent || "").replace(/\s+/g, " ").trim();
        summaryFullHtml = summaryEl.innerHTML.trim();
      }

      const wordsEl = card.querySelector("dd.words");
      const chaptersEl = card.querySelector("dd.chapters");
      const kudosEl = card.querySelector("dd.kudos");
      const hitsEl = card.querySelector("dd.hits");

      const wordsVal = wordsEl ? wordsEl.textContent.trim() : "0";
      const chaptersVal = chaptersEl ? chaptersEl.textContent.trim() : "1/1";
      const kudosVal = kudosEl ? kudosEl.textContent.trim() : "";
      const hitsVal = hitsEl ? hitsEl.textContent.trim() : "";

      card.dataset.kaelisRebuilt = "1";
      let isExpanded = false;

      const TAG_LIMIT = 3;
      const SUMMARY_LIMIT = 54;
      const hasMoreTags = allTags.length > TAG_LIMIT;
      const hasMoreSummary = summaryPlainText.length > SUMMARY_LIMIT || summaryParaCount > 1;
      const canExpand = hasMoreTags || hasMoreSummary || titleText.length > 18 || fandomText.length > 16;

      function renderCardContent() {
        const shownTags = isExpanded ? allTags : allTags.slice(0, TAG_LIMIT);
        const hiddenTagCount = Math.max(0, allTags.length - TAG_LIMIT);

        // When collapsed: ALWAYS a fixed 2-line box (height: 3.35em) so every single card has the exact same height!
        let summarySectionHtml = "";
        if (!isExpanded) {
          const displayStr = summaryPlainText
            ? (summaryPlainText.length > SUMMARY_LIMIT ? summaryPlainText.slice(0, SUMMARY_LIMIT) + "…" : summaryPlainText)
            : "暂无简介，点击标题可直接阅读正文。";
          summarySectionHtml = `
            <div class="__kaelis_summary_area" style="margin:8px 0 4px 0;height:3.35em;min-height:3.35em;max-height:3.35em;font-size:var(--ui-size);line-height:1.675;color:${summaryPlainText ? "var(--ao3-text)" : "var(--ao3-subtext)"};display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;cursor:${canExpand ? "pointer" : "default"};">
              ${displayStr}
            </div>
          `;
        } else {
          summarySectionHtml = `
            <div class="__kaelis_summary_area" style="margin:10px 0 6px 0;font-size:var(--ui-size);line-height:1.72;color:var(--ao3-text);cursor:pointer;">
              ${summaryFullHtml || "暂无简介"}
            </div>
          `;
        }

        const statsParts = [];
        statsParts.push(`<span>字数: ${wordsVal}</span>`);
        statsParts.push(`<span>章节: ${chaptersVal}</span>`);
        if (kudosVal) statsParts.push(`<span>♥ ${kudosVal}</span>`);
        else if (hitsVal) statsParts.push(`<span>点击: ${hitsVal}</span>`);

        card.innerHTML = `
          <!-- Row 1: Dedicated Full-Width Large Article Title! -->
          <a href="${workUrl}" style="display:block;width:100%;font-size:calc(var(--ui-size)*1.20);font-weight:800;color:var(--ao3-accent);line-height:1.38;margin-bottom:6px;${isExpanded ? "" : "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"}">
            ${titleText}
          </a>

          <!-- Row 2: CP Badge + Author + Date + Fandom (Single line when collapsed!) -->
          <div style="display:flex;align-items:center;gap:6px;font-size:calc(var(--ui-size)*0.80);color:var(--ao3-subtext);margin-bottom:8px;${isExpanded ? "flex-wrap:wrap;" : "white-space:nowrap;overflow:hidden;"}">
            ${cpBadgeText ? `
              <span style="flex-shrink:0;max-width:42%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:2px 9px;border-radius:999px;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ui-size)*0.76);font-weight:700;">
                ${cpBadgeText}
              </span>
            ` : ""}
            <span style="${isExpanded ? "" : "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"}flex:1;min-width:0;">
              作者 ${authorHtml}${dateStr ? ` · ${dateStr}` : ""}${fandomText ? ` · ${fandomText}` : ""}
            </span>
          </div>

          <!-- Row 3: Tags Row (Fixed 1-row height when collapsed so all cards stay uniform!) -->
          <div style="display:flex;align-items:center;gap:6px;margin:6px 0;${isExpanded ? "flex-wrap:wrap;" : "height:28px;overflow:hidden;white-space:nowrap;"}">
            ${shownTags.map(t => `
              <a href="${t.href}" style="flex-shrink:${isExpanded ? "1" : "0"};max-width:${isExpanded ? "100%" : "130px"};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:3px 10px;border-radius:9px;background:${t.isRel ? "var(--ao3-accent-soft)" : "var(--ao3-pill-bg)"};border:1px solid var(--ao3-border);color:${t.isRel ? "var(--ao3-accent)" : "var(--ao3-text)"};font-size:calc(var(--ui-size)*0.76);font-weight:${t.isRel ? "700" : "500"};line-height:1.4;">
                ${t.text}
              </a>
            `).join("")}
            ${!isExpanded && hiddenTagCount > 0 ? `
              <span class="__kaelis_expand_trigger" style="flex-shrink:0;padding:3px 9px;border-radius:9px;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ui-size)*0.75);font-weight:700;line-height:1.4;cursor:pointer;">
                +${hiddenTagCount} ▾
              </span>
            ` : ""}
          </div>

          <!-- Row 4: Summary Box (Fixed 2-line height when collapsed!) -->
          ${summarySectionHtml}

          <!-- Row 5: Single-Line Footer (Never wraps onto 2 lines!) -->
          <div style="margin-top:8px;padding-top:9px;border-top:1px solid var(--ao3-border);height:28px;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:calc(var(--ui-size)*0.78);color:var(--ao3-subtext);white-space:nowrap;">
            <div style="display:flex;align-items:center;gap:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1;">
              ${statsParts.join("")}
            </div>
            ${canExpand ? `
              <button type="button" class="__kaelis_expand_trigger" style="flex-shrink:0;padding:4px 12px;border-radius:999px;border:none;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ui-size)*0.76);font-weight:700;cursor:pointer;">
                ${isExpanded ? "收起内容 ▴" : "展开内容 ▾"}
              </button>
            ` : `
              <a href="${workUrl}" style="flex-shrink:0;padding:4px 12px;border-radius:999px;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ui-size)*0.76);font-weight:700;">
                阅读正文 →
              </a>
            `}
          </div>
        `;

        card.querySelectorAll(".__kaelis_expand_trigger").forEach(btn => {
          btn.addEventListener("click", function(e) {
            e.preventDefault();
            e.stopPropagation();
            isExpanded = !isExpanded;
            renderCardContent();
          });
        });

        const sumArea = card.querySelector(".__kaelis_summary_area");
        if (sumArea && canExpand) {
          sumArea.addEventListener("click", function(e) {
            if (e.target && e.target.tagName === "A") return;
            isExpanded = !isExpanded;
            renderCardContent();
          });
        }
      }

      renderCardContent();
    });
  }

  function formatDatesOnPage() {
    if (document.body && document.body.dataset.kaelisDatesFormatted === "1") return;
    const dateEls = document.querySelectorAll("p.datetime, span.datetime, dd.published, dd.status, .news .meta");
    dateEls.forEach(el => {
      const converted = convertDateString(el.textContent || "");
      if (converted && converted !== el.textContent) {
        el.textContent = converted;
      }
    });
    if (document.readyState === "complete" && document.body) {
      document.body.dataset.kaelisDatesFormatted = "1";
    }
  }

  function enhanceWorkMetaBox() {
    const workMeta = document.querySelector("dl.work.meta.group");
    if (workMeta && !workMeta.querySelector("#__ao3_meta_toggle")) {
      const toggleBar = document.createElement("div");
      toggleBar.id = "__ao3_meta_toggle";
      toggleBar.style.cssText = "display:flex;align-items:center;justify-content:space-between;cursor:pointer;font-size:calc(var(--ui-size)*0.86);font-weight:700;color:var(--ao3-accent);";
      toggleBar.innerHTML = `<span>📋 作品标签与统计详情（点击展开）</span><span id="__ao3_meta_arrow">▾</span>`;
      toggleBar.addEventListener("click", () => {
        const open = workMeta.classList.toggle("__ao3_meta_open");
        toggleBar.querySelector("#__ao3_meta_arrow").textContent = open ? "▴" : "▾";
        toggleBar.querySelector("span").textContent = open ? "📋 收起作品标签与统计详情" : "📋 作品标签与统计详情（点击展开）";
      });
      workMeta.prepend(toggleBar);
    }
  }

  // Run DOM translation once when page finishes loading so it never lags scrolling!
  function translateDOMOnce() {
    if (!store.zhTranslate || !document.body) return;
    if (document.body.dataset.kaelisTranslated === "1" && document.readyState === "complete") return;

    document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(btn => {
      const val = (btn.value || "").trim();
      if (ZH_DICT[val]) btn.value = ZH_DICT[val];
    });

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      const raw = node.nodeValue.trim();
      if (!raw) continue;
      if (ZH_DICT[raw] !== undefined) {
        node.nodeValue = node.nodeValue.replace(raw, ZH_DICT[raw]);
      } else if (raw.startsWith("You searched for:")) {
        node.nodeValue = raw
          .replace("You searched for:", "当前搜索：")
          .replace("sort by:", "排序：")
          .replace("best match", "最佳匹配")
          .replace("date posted", "发布时间")
          .replace("date updated", "更新时间")
          .replace("word count", "字数")
          .replace("kudos", "点赞数")
          .replace("hits", "点击量")
          .replace("descending", "降序")
          .replace("ascending", "升序");
      } else if (raw.endsWith(" Found")) {
        node.nodeValue = "共找到 " + raw.replace(" Found", "") + " 篇作品";
      } else if (raw.startsWith("Browse fandoms by media")) {
        node.nodeValue = "按分类浏览同人圈，点进感兴趣的分类即可按作品热度筛选：";
      }
    }

    if (document.readyState === "complete") {
      document.body.dataset.kaelisTranslated = "1";
    }
  }

  // ==================== ULTRA-CLEAN SINGLE-CARD PAGE FLIP READER (Uses --reader-size & --reader-font!) ====================
  let pagedState = {
    pages: [],
    currentIndex: 0,
    workTitle: "阅读正文"
  };

  function collectStoryUnits() {
    const workskin = document.getElementById("workskin");
    if (!workskin) return [];
    const units = [];

    const titleEl = workskin.querySelector("h2.title.heading");
    const authorEl = workskin.querySelector("h3.byline.heading");
    if (titleEl) {
      pagedState.workTitle = titleEl.textContent.trim();
      units.push(
        `<div style="margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--ao3-border);">
           <div style="font-size:calc(var(--reader-size)*1.15);font-weight:800;color:var(--ao3-accent);line-height:1.4;">${titleEl.textContent.trim()}</div>
           ${authorEl ? `<div style="font-size:calc(var(--reader-size)*0.76);color:var(--ao3-subtext);margin-top:4px;">作者：${authorEl.textContent.trim()}</div>` : ""}
         </div>`
      );
    }

    const paras = workskin.querySelectorAll("#chapters .userstuff p, div.userstuff p");
    if (paras.length > 0) {
      paras.forEach(p => {
        const text = (p.textContent || "").trim();
        if (!text || text === "Chapter Text") return;
        if (text.length > 90) {
          const sentences = text.match(/[^。！？!?]+[。！？!?”’”]*/g) || [text];
          let chunk = "";
          sentences.forEach(s => {
            if ((chunk + s).length > 80 && chunk.length > 0) {
              units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${chunk}</p>`);
              chunk = s;
            } else {
              chunk += s;
            }
          });
          if (chunk) {
            units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${chunk}</p>`);
          }
        } else {
          units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${p.innerHTML}</p>`);
        }
      });
    } else {
      const userstuff = workskin.querySelector("#chapters .userstuff, div.userstuff");
      if (userstuff) {
        const lines = userstuff.innerHTML.split(/<br\s*\/?>/i);
        lines.forEach(l => {
          const clean = l.trim();
          if (clean && clean !== "Chapter Text") {
            units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${clean}</p>`);
          }
        });
      }
    }
    return units;
  }

  function buildDiscretePages() {
    const readerOverlay = document.getElementById("__ao3_paged_reader");
    const workskin = document.getElementById("workskin");

    if (store.reader.readingMode !== "page" || !workskin) {
      document.body.classList.remove("__ao3_paged_active");
      if (readerOverlay) readerOverlay.style.display = "none";
      document.body.style.overflow = "";
      return;
    }

    document.body.classList.add("__ao3_paged_active");
    document.body.style.overflow = "hidden";

    let overlay = readerOverlay;
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "__ao3_paged_reader";
      overlay.style.cssText = "position:fixed;inset:0;z-index:9990;display:flex;flex-direction:column;padding:10px 12px;box-sizing:border-box;user-select:none;";
      overlay.innerHTML = `
        <div style="flex:1;min-height:0;background:var(--ao3-card-bg);border:1px solid var(--ao3-border);border-radius:22px;padding:14px 20px 12px 20px;display:flex;flex-direction:column;justify-content:space-between;position:relative;box-sizing:border-box;box-shadow:0 6px 20px rgba(42,32,68,0.05);">

          <div style="height:26px;padding-bottom:8px;margin-bottom:10px;border-bottom:1px solid var(--ao3-border);display:flex;align-items:center;justify-content:space-between;font-size:12px !important;color:var(--ao3-subtext);flex-shrink:0;position:relative;z-index:10;white-space:nowrap;">
            <span id="__ao3_paged_exit" style="cursor:pointer;font-weight:700;color:var(--ao3-accent);font-size:12px !important;">‹ 切回滑动</span>
            <span id="__ao3_paged_title" style="max-width:54%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px !important;">阅读正文</span>
            <span id="__ao3_paged_settings" style="cursor:pointer;font-weight:700;color:var(--ao3-accent);font-size:12px !important;">阅读设置</span>
          </div>

          <div id="__ao3_page_box" style="flex:1;min-height:0;overflow:hidden;font-family:var(--reader-font);font-size:var(--reader-size);color:var(--ao3-text);"></div>

          <div style="position:absolute;inset:42px 0 40px 0;display:flex;z-index:5;">
            <div id="__ao3_Zone_Prev" style="width:38%;height:100%;cursor:pointer;"></div>
            <div id="__ao3_Zone_Mid" style="width:24%;height:100%;"></div>
            <div id="__ao3_Zone_Next" style="width:38%;height:100%;cursor:pointer;"></div>
          </div>

          <div style="height:26px;padding-top:8px;margin-top:6px;border-top:1px solid var(--ao3-border);display:flex;align-items:center;justify-content:space-between;font-size:12px !important;color:var(--ao3-subtext);flex-shrink:0;position:relative;z-index:10;white-space:nowrap;">
            <span id="__ao3_paged_indicator" style="font-size:12px !important;font-weight:600;">1 / 1</span>
            <div style="display:flex;align-items:center;gap:16px;font-size:12px !important;">
              <span id="__ao3_btn_p_prev" style="cursor:pointer;font-weight:600;font-size:12px !important;">上一页</span>
              <span id="__ao3_btn_p_next" style="cursor:pointer;font-weight:700;color:var(--ao3-accent);font-size:12px !important;">下一页</span>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);

      overlay.querySelector("#__ao3_paged_exit").addEventListener("click", () => {
        store.reader.readingMode = "scroll";
        const mb = document.getElementById("__ao3_mode_btn");
        if (mb) mb.textContent = "滑动模式";
        saveStore();
        applyAll();
      });
      overlay.querySelector("#__ao3_paged_settings").addEventListener("click", () => {
        if (window.__kaelisOpenSettingsModal) {
          window.__kaelisOpenSettingsModal("reader");
        }
      });
      overlay.querySelector("#__ao3_Zone_Prev").addEventListener("click", () => window.__ao3TurnPage("prev"));
      overlay.querySelector("#__ao3_Zone_Next").addEventListener("click", () => window.__ao3TurnPage("next"));
      overlay.querySelector("#__ao3_btn_p_prev").addEventListener("click", () => window.__ao3TurnPage("prev"));
      overlay.querySelector("#__ao3_btn_p_next").addEventListener("click", () => window.__ao3TurnPage("next"));
    }

    overlay.style.display = "flex";

    const pageBox = overlay.querySelector("#__ao3_page_box");
    const maxH = pageBox.clientHeight || (window.innerHeight - 120);
    const units = collectStoryUnits();

    const titleNode = overlay.querySelector("#__ao3_paged_title");
    if (titleNode) titleNode.textContent = pagedState.workTitle || "阅读正文";

    const pages = [];
    pageBox.innerHTML = "";
    let currentHtml = "";

    for (let i = 0; i < units.length; i++) {
      const u = units[i];
      pageBox.innerHTML = currentHtml + u;
      if (pageBox.scrollHeight > maxH && currentHtml !== "") {
        pages.push(currentHtml);
        currentHtml = u;
      } else {
        currentHtml += u;
      }
    }
    if (currentHtml) pages.push(currentHtml);
    if (pages.length === 0) pages.push("<p>暂无正文内容</p>");

    pagedState.pages = pages;
    if (pagedState.currentIndex >= pages.length) pagedState.currentIndex = pages.length - 1;
    if (pagedState.currentIndex < 0) pagedState.currentIndex = 0;

    renderCurrentDiscretePage();
  }

  function renderCurrentDiscretePage() {
    const overlay = document.getElementById("__ao3_paged_reader");
    if (!overlay || overlay.style.display === "none") return;
    const pageBox = overlay.querySelector("#__ao3_page_box");
    const indicator = overlay.querySelector("#__ao3_paged_indicator");
    const total = pagedState.pages.length;
    const idx = pagedState.currentIndex;
    pageBox.innerHTML = pagedState.pages[idx] || "";
    indicator.textContent = `${idx + 1} / ${total} 页`;
  }

  window.__ao3TurnPage = function(dir) {
    if (store.reader.readingMode === "page" && document.getElementById("workskin")) {
      const nextIdx = pagedState.currentIndex + (dir === "next" ? 1 : -1);
      if (nextIdx >= 0 && nextIdx < pagedState.pages.length) {
        pagedState.currentIndex = nextIdx;
        renderCurrentDiscretePage();
      } else if (nextIdx >= pagedState.pages.length) {
        const nextChap = document.querySelector("li.chapter.next a, a[rel='next']");
        if (nextChap && nextChap.href) {
          window.location.href = nextChap.href;
        }
      }
    } else {
      const step = Math.floor(window.innerHeight * 0.82);
      window.scrollTo(0, Math.max(0, window.scrollY + (dir === "next" ? step : -step)));
    }
  };

  window.__ao3VolumeKey = function(dir) {
    window.__ao3TurnPage(dir);
  };

  // ==================== DUAL-SCOPE SETTINGS MODAL (Separate "🏠 外部列表设置" vs "📖 正文阅读设置") ====================
  function buildSettingsModal() {
    if (!document.body || document.getElementById("__ao3_settings_modal")) return;
    let editingScope = isReadingWorkPage() ? "reader" : "ui";

    const modal = document.createElement("div");
    modal.id = "__ao3_settings_modal";
    modal.style.cssText = "position:fixed;inset:0;z-index:100000;background:rgba(20,16,28,0.45);display:none;align-items:flex-end;justify-content:center;";
    modal.innerHTML = `
      <div style="width:100%;max-width:480px;max-height:90vh;overflow-y:auto;background:#fbfafc;border-radius:28px 28px 0 0;padding:20px 20px 26px;color:#2c2638;box-shadow:0 -8px 32px rgba(0,0,0,0.18);font-family:sans-serif;box-sizing:border-box;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <div style="font-size:19px;font-weight:800;">Kaelis 独立外观设置</div>
          <button id="__ao3_close_modal" style="width:36px;height:36px;padding:0;border-radius:12px;border:1px solid #e6e2ec;background:#fff;font-size:16px;color:#555;">✕</button>
        </div>

        <!-- Scope Switcher Tabs: Outside UI vs Story Reader! -->
        <div style="display:flex;gap:6px;padding:4px;border-radius:14px;background:#ece8f4;margin-bottom:10px;">
          <button id="__ao3_tab_ui" style="flex:1;padding:9px 6px;border-radius:11px;border:none;font-size:13px;font-weight:700;cursor:pointer;">
            🏠 外部列表设置 (首页/搜索)
          </button>
          <button id="__ao3_tab_reader" style="flex:1;padding:9px 6px;border-radius:11px;border:none;font-size:13px;font-weight:700;cursor:pointer;">
            📖 正文阅读设置 (看文专属)
          </button>
        </div>

        <div id="__ao3_scope_desc" style="font-size:12px;color:#7a708e;margin-bottom:14px;"></div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">
          <span id="__ao3_fs_title">当前字号</span> • <span id="__ao3_fs_val">17</span> px
        </div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
          <button id="__ao3_fs_dec" style="width:44px;height:38px;padding:0;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A-</button>
          <input id="__ao3_fs_range" type="range" min="12" max="26" value="17" style="flex:1;" />
          <button id="__ao3_fs_inc" style="width:44px;height:38px;padding:0;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A+</button>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:6px;">字体选择</div>
        <select id="__ao3_font_sel" style="width:100%;padding:11px 14px;border-radius:14px;border:1px solid #e2dde9;background:#fff;font-size:14px;color:#2c2638;margin-bottom:14px;">
          <option value="system">系统默认字体（默认）</option>
          <option value="song">飞花宋体 / 思源宋体</option>
          <option value="kai">霞鹜文楷 / 传统楷体</option>
          <option value="hei">柔和黑体 / 无衬线</option>
        </select>

        <div id="__ao3_preview_box" style="padding:16px;border-radius:16px;border:1px solid #e2dde9;margin-bottom:16px;line-height:1.75;">
          浮光落在纸页上。他放下书，轻声说：<br>“不着急，慢慢读。”
        </div>

        <div id="__ao3_reader_mode_section" style="margin-bottom:16px;">
          <div style="font-size:14px;font-weight:700;margin-bottom:8px;">正文翻页方式</div>
          <div style="display:flex;gap:8px;">
            <button id="__ao3_set_scroll" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">上下滑动</button>
            <button id="__ao3_set_page" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">左右翻页(无动画)</button>
          </div>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:10px;">背景颜色与相册壁纸</div>
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:14px;flex-wrap:wrap;" id="__ao3_preset_row"></div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">色相</span>
          <input id="__ao3_hue" type="range" min="0" max="360" value="262" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">浓淡</span>
          <input id="__ao3_sat" type="range" min="0" max="80" value="28" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">明暗</span>
          <input id="__ao3_light" type="range" min="12" max="97" value="90" style="flex:1;" />
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;font-size:13px;color:#6e667e;">
          <span style="width:72px;">背景透明度</span>
          <input id="__ao3_opacity" type="range" min="20" max="100" value="88" style="flex:1;" />
          <span id="__ao3_op_val" style="width:38px;text-align:right;">88%</span>
        </div>

        <div style="display:flex;gap:10px;margin-bottom:18px;">
          <label style="flex:1;padding:11px;border-radius:12px;border:1px dashed #b8aed0;background:#f5f2fa;color:#524668;font-size:13px;font-weight:700;text-align:center;cursor:pointer;">
            🖼️ 选择相册背景图
            <input id="__ao3_bg_file" type="file" accept="image/*" style="display:none;" />
          </label>
          <button id="__ao3_clear_bg" style="padding:11px 14px;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-size:13px;color:#666;">清除背景图</button>
        </div>

        <div style="display:flex;gap:12px;">
          <button id="__ao3_reset_btn" style="flex:1;padding:13px;border-radius:14px;border:1px solid #dcd6e8;background:#fff;font-size:15px;font-weight:700;color:#554d66;">恢复默认</button>
          <button id="__ao3_save_btn" style="flex:1;padding:13px;border-radius:14px;border:none;background:#3b3746;font-size:15px;font-weight:700;color:#fff;">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    function getTargetObj() {
      return editingScope === "reader" ? store.reader : store.ui;
    }

    function syncModalControls() {
      const target = getTargetObj();
      const tabUi = modal.querySelector("#__ao3_tab_ui");
      const tabReader = modal.querySelector("#__ao3_tab_reader");
      const desc = modal.querySelector("#__ao3_scope_desc");
      const fsTitle = modal.querySelector("#__ao3_fs_title");

      if (editingScope === "reader") {
        tabReader.style.background = "#ffffff";
        tabReader.style.color = "#3b3054";
        tabReader.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)";
        tabUi.style.background = "transparent";
        tabUi.style.color = "#7a708e";
        tabUi.style.boxShadow = "none";
        desc.textContent = "当前正在调节【正文阅读页面】：你可以把正文字号调大，完全不会影响外面的搜索卡片排版！";
        fsTitle.textContent = "正文阅读字号";
      } else {
        tabUi.style.background = "#ffffff";
        tabUi.style.color = "#3b3054";
        tabUi.style.boxShadow = "0 2px 8px rgba(0,0,0,0.08)";
        tabReader.style.background = "transparent";
        tabReader.style.color = "#7a708e";
        tabReader.style.boxShadow = "none";
        desc.textContent = "当前正在调节【首页与搜索列表】：保持适中字号（推荐 14–16px），卡片排列最精致美观。";
        fsTitle.textContent = "外部列表字号";
      }

      modal.querySelector("#__ao3_fs_val").textContent = target.fontSize;
      modal.querySelector("#__ao3_fs_range").value = target.fontSize;
      modal.querySelector("#__ao3_font_sel").value = target.fontFamily;
      modal.querySelector("#__ao3_hue").value = target.hue;
      modal.querySelector("#__ao3_sat").value = target.sat;
      modal.querySelector("#__ao3_light").value = target.light;
      modal.querySelector("#__ao3_opacity").value = target.bgOpacity;
      modal.querySelector("#__ao3_op_val").textContent = target.bgOpacity + "%";

      const box = modal.querySelector("#__ao3_preview_box");
      box.style.fontSize = target.fontSize + "px";
      box.style.fontFamily = getFontStack(target.fontFamily);
      box.style.background = `hsl(${target.hue}, ${target.sat}%, ${target.light}%)`;
      box.style.color = target.light < 36 ? "#f2eef8" : "#2c2638";
    }

    window.__kaelisOpenSettingsModal = function(scope) {
      editingScope = scope || (isReadingWorkPage() ? "reader" : "ui");
      syncModalControls();
      modal.style.display = "flex";
    };

    modal.querySelector("#__ao3_tab_ui").addEventListener("click", () => {
      editingScope = "ui";
      syncModalControls();
    });
    modal.querySelector("#__ao3_tab_reader").addEventListener("click", () => {
      editingScope = "reader";
      syncModalControls();
    });

    const presetRow = modal.querySelector("#__ao3_preset_row");
    PRESETS.forEach(p => {
      const dot = document.createElement("div");
      dot.className = "__ao3_color_dot";
      dot.title = p.name;
      dot.style.background = `hsl(${p.h},${p.s}%,${p.l}%)`;
      dot.style.border = "2px solid #b5abc9";
      dot.addEventListener("click", () => {
        const t = getTargetObj();
        t.hue = p.h;
        t.sat = p.s;
        t.light = p.l;
        syncModalControls();
        applyAll();
      });
      presetRow.appendChild(dot);
    });

    modal.querySelector("#__ao3_close_modal").addEventListener("click", () => modal.style.display = "none");
    modal.querySelector("#__ao3_save_btn").addEventListener("click", () => {
      saveStore();
      modal.style.display = "none";
    });
    modal.querySelector("#__ao3_reset_btn").addEventListener("click", () => {
      if (editingScope === "reader") {
        store.reader = JSON.parse(JSON.stringify(DEFAULT_STORE.reader));
      } else {
        store.ui = JSON.parse(JSON.stringify(DEFAULT_STORE.ui));
      }
      saveStore();
      syncModalControls();
      applyAll();
    });

    modal.querySelector("#__ao3_fs_range").addEventListener("input", e => {
      const t = getTargetObj();
      t.fontSize = parseInt(e.target.value, 10);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_fs_dec").addEventListener("click", () => {
      const t = getTargetObj();
      t.fontSize = Math.max(12, t.fontSize - 1);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_fs_inc").addEventListener("click", () => {
      const t = getTargetObj();
      t.fontSize = Math.min(26, t.fontSize + 1);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_font_sel").addEventListener("change", e => {
      const t = getTargetObj();
      t.fontFamily = e.target.value;
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_hue").addEventListener("input", e => {
      const t = getTargetObj();
      t.hue = parseInt(e.target.value, 10);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_sat").addEventListener("input", e => {
      const t = getTargetObj();
      t.sat = parseInt(e.target.value, 10);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_light").addEventListener("input", e => {
      const t = getTargetObj();
      t.light = parseInt(e.target.value, 10);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_opacity").addEventListener("input", e => {
      const t = getTargetObj();
      t.bgOpacity = parseInt(e.target.value, 10);
      syncModalControls();
      applyAll();
    });
    modal.querySelector("#__ao3_set_scroll").addEventListener("click", () => {
      store.reader.readingMode = "scroll";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "滑动模式";
      saveStore();
      applyAll();
    });
    modal.querySelector("#__ao3_set_page").addEventListener("click", () => {
      store.reader.readingMode = "page";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "翻页模式";
      saveStore();
      applyAll();
    });
    modal.querySelector("#__ao3_bg_file").addEventListener("change", e => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function(ev) {
        const t = getTargetObj();
        t.bgImage = ev.target.result;
        saveStore();
        applyAll();
      };
      reader.readAsDataURL(file);
    });
    modal.querySelector("#__ao3_clear_bg").addEventListener("click", () => {
      const t = getTargetObj();
      t.bgImage = "";
      saveStore();
      applyAll();
    });

    syncModalControls();
  }

  function applyAll() {
    ensureViewportMeta();
    injectStyles();
    if (!document.body) return;
    ensureBgLayers();
    buildCustomHeader();
    formatDatesOnPage();
    rebuildBlurbCardsUniform();
    enhanceWorkMetaBox();
    translateDOMOnce();
    buildSettingsModal();
    buildDiscretePages();
  }

  window.__ao3ApplyAll = applyAll;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyAll);
  } else {
    applyAll();
  }
})();
