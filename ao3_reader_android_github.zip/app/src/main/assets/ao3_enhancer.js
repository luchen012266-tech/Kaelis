(function() {
  if (window.__ao3EnhancerV2Loaded) {
    if (window.__ao3ApplyAll) window.__ao3ApplyAll();
    return;
  }
  window.__ao3EnhancerV2Loaded = true;

  const DEFAULT_CONFIG = {
    fontSize: 17,
    fontFamily: "system",
    hue: 262,
    sat: 28,
    light: 90,
    bgImage: "",
    bgOpacity: 78,
    readingMode: "scroll", // "scroll" or "page"
    zhTranslate: true
  };

  let config = Object.assign({}, DEFAULT_CONFIG);
  try {
    const saved = localStorage.getItem("__ao3_custom_reader_cfg_v2");
    if (saved) config = Object.assign({}, DEFAULT_CONFIG, JSON.parse(saved));
  } catch (e) {}

  try {
    const savedBg = localStorage.getItem("__ao3_custom_reader_bg_v1");
    if (savedBg) config.bgImage = savedBg;
  } catch (e) {}

  function saveConfig() {
    try {
      const copy = Object.assign({}, config, { bgImage: "" });
      localStorage.setItem("__ao3_custom_reader_cfg_v2", JSON.stringify(copy));
      if (config.bgImage) {
        localStorage.setItem("__ao3_custom_reader_bg_v1", config.bgImage);
      } else {
        localStorage.removeItem("__ao3_custom_reader_bg_v1");
      }
    } catch (e) {}
  }

  const PRESETS = [
    { name: "雾紫", h: 262, s: 28, l: 90 },
    { name: "丁香", h: 258, s: 45, l: 84 },
    { name: "烟粉", h: 310, s: 26, l: 88 },
    { name: "暮山紫", h: 256, s: 22, l: 76 },
    { name: "云水蓝", h: 220, s: 16, l: 92 },
    { name: "羊皮纸", h: 42, s: 38, l: 93 },
    { name: "夜间黑", h: 240, s: 14, l: 15 }
  ];

  // Comprehensive dictionary covering Home, Search, Blurbs, Stats, Warnings, and Work Reading Page
  const ZH_DICT = {
    "Fandoms": "同人圈",
    "Browse": "浏览",
    "Search": "搜索",
    "About": "关于",
    "Log In": "登录",
    "Log Out": "退出",
    "Post": "发布",
    "New Work": "发布新作",
    "Import Work": "导入作品",
    "Hi,": "你好，",
    "My Dashboard": "个人主页",
    "Dashboard": "主页",
    "Profile": "个人资料",
    "Preferences": "偏好设置",
    "Skins": "网站皮肤",
    "Works": "作品",
    "Drafts": "草稿",
    "Series": "系列",
    "Bookmarks": "收藏书签",
    "Collections": "合集",
    "Inbox": "收件箱",
    "Statistics": "数据统计",
    "History": "阅读历史",
    "Subscriptions": "我的订阅",
    "Co-Creators": "联合创作者",
    "Find your favorites": "探索你喜欢的同人圈",
    "All Fandoms": "全部同人圈",
    "Anime & Manga": "动漫与漫画 (ACG)",
    "Books & Literature": "书籍与文学",
    "Cartoons & Comics & Graphic Novels": "卡通、美漫与绘本",
    "Celebrities & Real People": "真人影视与明星 (RPS)",
    "Movies": "电影专区",
    "Music & Bands": "音乐与乐队",
    "Other Media": "其他衍生媒体",
    "Theater": "戏剧与音乐剧",
    "TV Shows": "电视剧集",
    "Video Games": "电子游戏",
    "Uncategorized Fandoms": "未分类同人圈",
    "News": "站内公告",
    "All News": "全部公告",
    "Search Results": "搜索结果",
    "Edit Your Search": "修改搜索条件",
    "Sort and Filter": "排序与筛选",
    "Sort by": "排序方式",
    "Best Match": "最佳匹配",
    "Author": "作者",
    "Title": "标题",
    "Date Posted": "发布日期",
    "Date Updated": "更新日期",
    "Word Count": "字数统计",
    "Hits": "点击量",
    "Kudos": "点赞数 (Kudos)",
    "Comments": "评论数",
    "Bookmarks:": "收藏：",
    "Collections:": "合集：",
    "Comments:": "评论：",
    "Kudos:": "点赞：",
    "Hits:": "点击：",
    "Words:": "字数：",
    "Chapters:": "章节：",
    "Language:": "语言：",
    "Series:": "系列：",
    "Published:": "发布：",
    "Updated:": "更新：",
    "Completed:": "完结：",
    "Status:": "状态：",
    "Rating": "分级",
    "Rating:": "分级：",
    "Archive Warning": "归档警告",
    "Archive Warnings": "归档警告",
    "Archive Warning:": "归档警告：",
    "Archive Warnings:": "归档警告：",
    "Category": "性向分类",
    "Categories": "性向分类",
    "Category:": "性向分类：",
    "Categories:": "性向分类：",
    "Fandom": "原作圈",
    "Fandom:": "原作圈：",
    "Fandoms:": "原作圈：",
    "Relationship": "配对/CP",
    "Relationships": "配对/CP",
    "Relationship:": "配对/CP：",
    "Relationships:": "配对/CP：",
    "Character": "角色",
    "Characters": "角色",
    "Character:": "角色：",
    "Characters:": "角色：",
    "Additional Tags": "附加标签",
    "Additional Tags:": "附加标签：",
    "Stats": "数据统计",
    "Stats:": "统计：",
    "Summary": "作品简介",
    "Summary:": "作品简介",
    "Notes": "作者的话",
    "Notes:": "作者的话",
    "Work Text": "正文内容",
    "Work Text:": "正文内容",
    "Entire Work": "全文阅读",
    "Chapter by Chapter": "分章阅读",
    "Chapter Index": "章节目录",
    "Next Chapter →": "下一章 →",
    "← Previous Chapter": "← 上一章",
    "Kudos ♥": "♥ 点赞",
    "Bookmark": "收藏",
    "Subscribe": "订阅",
    "Download": "下载",
    "Share": "分享",
    "Top": "返回顶部",
    "No Archive Warnings Apply": "无归档警告",
    "Creator Chose Not To Use Archive Warnings": "作者未标注归档警告",
    "Graphic Depictions Of Violence": "含暴力描写",
    "Major Character Death": "主要角色死亡",
    "Underage": "未成年相关警告",
    "Rape/Non-Con": "非自愿警告",
    "General Audiences": "全年龄 (G)",
    "Teen And Up Audiences": "青少年及以上 (T)",
    "Mature": "成熟级 (M)",
    "Explicit": "限制级 (E)",
    "Not Rated": "未分级"
  };

  function getFontStack(key) {
    if (key === "song") return "'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', 'SimSun', serif";
    if (key === "kai") return "'LXGW WenKai', 'Kaiti SC', 'STKaiti', 'KaiTi', serif";
    if (key === "hei") return "'PingFang SC', 'HarmonyOS Sans SC', 'Microsoft YaHei', sans-serif";
    return "-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Segoe UI', Roboto, sans-serif";
  }

  function ensureViewportMeta() {
    if (!document.head) return;
    let vp = document.querySelector('meta[name="viewport"]');
    if (!vp) {
      vp = document.createElement("meta");
      vp.name = "viewport";
      document.head.appendChild(vp);
    }
    vp.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no";
  }

  function injectStyles() {
    if (!document.head) return;
    let styleEl = document.getElementById("__ao3_custom_style_v2");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "__ao3_custom_style_v2";
      document.head.appendChild(styleEl);
    }

    const isDark = config.light < 36;
    const textColor = isDark ? "#f0ecf8" : "#2b2538";
    const subTextColor = isDark ? "#aba2be" : "#706782";
    const accentColor = `hsl(${config.hue}, ${Math.min(config.sat + 28, 72)}%, ${isDark ? 70 : 42}%)`;
    const accentSoft = isDark
      ? `hsla(${config.hue}, ${Math.min(config.sat + 25, 65)}%, 60%, 0.18)`
      : `hsla(${config.hue}, ${Math.min(config.sat + 25, 65)}%, 48%, 0.12)`;
    const pageBgHsl = `hsl(${config.hue}, ${config.sat}%, ${config.light}%)`;
    const cardAlpha = Math.max(0.18, Math.min(0.98, config.bgOpacity / 100));
    const cardBg = isDark
      ? `rgba(34, 30, 44, ${cardAlpha})`
      : `rgba(255, 255, 255, ${cardAlpha})`;
    const pillBg = isDark
      ? `rgba(52, 46, 66, 0.78)`
      : `rgba(255, 255, 255, 0.76)`;
    const borderCol = isDark
      ? "rgba(255, 255, 255, 0.12)"
      : "rgba(165, 152, 195, 0.28)";
    const fontStack = getFontStack(config.fontFamily);

    styleEl.textContent = `
      :root {
        --ao3-bg: ${pageBgHsl};
        --ao3-card-bg: ${cardBg};
        --ao3-pill-bg: ${pillBg};
        --ao3-border: ${borderCol};
        --ao3-text: ${textColor};
        --ao3-subtext: ${subTextColor};
        --ao3-accent: ${accentColor};
        --ao3-accent-soft: ${accentSoft};
        --ao3-font: ${fontStack};
        --ao3-font-size: ${config.fontSize}px;
      }

      /* 1. Hide AO3's ugly native header & footer clutter */
      #header, #footer {
        display: none !important;
      }

      html, body, #outer, #inner {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ao3-font) !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        overflow-x: hidden !important;
      }

      #main {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ao3-font) !important;
        padding: 12px 12px 84px 12px !important;
        margin: 0 auto !important;
        max-width: 680px !important;
        box-sizing: border-box !important;
      }

      /* Fixed Background & Opacity Layers */
      #__ao3_bg_layer {
        position: fixed !important;
        inset: 0 !important;
        z-index: -2 !important;
        background-color: var(--ao3-bg) !important;
        background-image: ${config.bgImage ? `url("${config.bgImage}")` : "none"} !important;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
      }

      #__ao3_bg_overlay {
        position: fixed !important;
        inset: 0 !important;
        z-index: -1 !important;
        background-color: var(--ao3-bg) !important;
        opacity: ${config.bgImage ? (100 - config.bgOpacity) / 100 : 1} !important;
        pointer-events: none !important;
      }

      /* 2. Eliminate ALL AO3 classic #900 red and dotted underlines everywhere */
      h1, h2, h3, h4, h5, h6,
      .heading, .splash .module h3,
      .splash .browse li a:before,
      span.symbol, .question {
        color: var(--ao3-accent) !important;
        border-bottom-color: var(--ao3-border) !important;
        font-family: var(--ao3-font) !important;
      }

      a, a:link, a:visited, a:hover, a:active,
      .blurb h4 a, .blurb ul a, dl.stats a, abbr {
        color: var(--ao3-text) !important;
        border-bottom: none !important;
        text-decoration: none !important;
        background: transparent !important;
      }

      /* 3. Home Page (.splash) clean card transformation */
      .splash .module, .splash .browse, .splash .news {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 22px !important;
        padding: 16px !important;
        margin: 0 0 14px 0 !important;
        box-shadow: 0 8px 24px rgba(42, 32, 68, 0.06) !important;
        width: 100% !important;
        float: none !important;
        box-sizing: border-box !important;
      }

      .splash .browse ul {
        display: grid !important;
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 8px !important;
        padding: 0 !important;
        margin: 10px 0 0 0 !important;
      }

      .splash .browse li {
        width: 100% !important;
        float: none !important;
        margin: 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .splash .browse li a {
        display: block !important;
        padding: 10px 12px !important;
        background: var(--ao3-pill-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 14px !important;
        font-size: 13px !important;
        font-weight: 600 !important;
        color: var(--ao3-text) !important;
      }

      /* 4. Search Results & Work Blurb Cards (Fix the giant 4 squares & ugly grey stats oval!) */
      ol.work.index.group, ul.index.group, ol.bookmark.index.group {
        padding: 0 !important;
        margin: 0 !important;
        list-style: none !important;
      }

      li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border-radius: 22px !important;
        border: 1px solid var(--ao3-border) !important;
        padding: 16px 16px 14px 16px !important;
        margin: 14px 0 !important;
        box-shadow: 0 8px 24px rgba(42, 32, 68, 0.06) !important;
        position: relative !important;
        overflow: hidden !important;
      }

      /* Hide AO3's giant 4 square icons column on the left so title is full-width */
      li.blurb .header ul.required-tags {
        display: none !important;
      }

      li.blurb .header {
        margin: 0 0 8px 0 !important;
        padding: 0 !important;
        min-height: 0 !important;
      }

      li.blurb .header h4.heading {
        margin: 0 0 4px 0 !important;
        padding: 0 !important;
        font-size: 17px !important;
        line-height: 1.4 !important;
        font-weight: 700 !important;
      }

      li.blurb .header h4.heading a:first-child {
        color: var(--ao3-accent) !important;
        font-size: 17px !important;
        font-weight: 700 !important;
      }

      li.blurb .header p.datetime {
        position: static !important;
        float: none !important;
        margin: 2px 0 4px 0 !important;
        font-size: 11px !important;
        color: var(--ao3-subtext) !important;
      }

      li.blurb .header h5.fandoms.heading {
        margin: 4px 0 !important;
        padding: 0 !important;
        font-size: 12px !important;
        color: var(--ao3-subtext) !important;
      }

      /* Transform messy comma tags into clean modern rounded pills */
      li.blurb ul.tags.commas {
        margin: 8px 0 !important;
        padding: 0 !important;
        list-style: none !important;
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 6px !important;
      }

      li.blurb ul.tags.commas li {
        display: inline-block !important;
        margin: 0 !important;
        padding: 3px 9px !important;
        border-radius: 9px !important;
        background: var(--ao3-pill-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        font-size: 11.5px !important;
        line-height: 1.4 !important;
      }

      /* Highlight Relationship / CP tags */
      li.blurb ul.tags.commas li.relationships {
        background: var(--ao3-accent-soft) !important;
        border-color: transparent !important;
        font-weight: 600 !important;
      }
      li.blurb ul.tags.commas li.relationships a {
        color: var(--ao3-accent) !important;
      }

      /* Hide trailing commas added by AO3 */
      li.blurb ul.tags.commas li::after,
      ul.commas li::after {
        content: "" !important;
      }

      /* Partial display when card is collapsed: show only first 5 tags & 2 lines of summary */
      li.blurb:not(.__ao3_expanded) ul.tags.commas li:nth-child(n+6) {
        display: none !important;
      }

      li.blurb blockquote.userstuff.summary {
        margin: 8px 0 !important;
        padding: 0 !important;
        border: none !important;
        background: transparent !important;
        font-size: 13.5px !important;
        line-height: 1.65 !important;
        color: var(--ao3-text) !important;
      }

      li.blurb:not(.__ao3_expanded) blockquote.userstuff.summary {
        display: -webkit-box !important;
        -webkit-line-clamp: 2 !important;
        -webkit-box-orient: vertical !important;
        overflow: hidden !important;
      }

      /* Fix ugly grey oval dl.stats at bottom of card! */
      li.blurb dl.stats {
        background: transparent !important;
        border: none !important;
        border-top: 1px solid var(--ao3-border) !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        padding: 10px 0 4px 0 !important;
        margin: 10px 0 0 0 !important;
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 4px 10px !important;
        font-size: 11.5px !important;
        color: var(--ao3-subtext) !important;
        justify-content: flex-start !important;
        text-align: left !important;
      }

      li.blurb dl.stats dt, li.blurb dl.stats dd {
        display: inline !important;
        float: none !important;
        margin: 0 !important;
        padding: 0 !important;
      }

      .__ao3_card_toggle {
        margin-top: 8px !important;
        padding: 7px 14px !important;
        border-radius: 12px !important;
        background: var(--ao3-accent-soft) !important;
        color: var(--ao3-accent) !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        text-align: center !important;
        cursor: pointer !important;
        user-select: none !important;
      }

      /* 5. Work Reading View (#workskin, #chapters, dl.work.meta.group) */
      dl.work.meta.group {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(14px) !important;
        -webkit-backdrop-filter: blur(14px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 20px !important;
        padding: 14px 16px !important;
        margin: 0 0 12px 0 !important;
        box-shadow: none !important;
      }

      dl.work.meta.group:not(.__ao3_meta_open) > dt,
      dl.work.meta.group:not(.__ao3_meta_open) > dd {
        display: none !important;
      }

      #workskin {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 24px !important;
        padding: 20px 18px !important;
        margin: 0 !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        box-shadow: 0 8px 28px rgba(42, 32, 68, 0.06) !important;
      }

      /* Fix narrow squeezed Summary / Notes in work preface! */
      #workskin .preface,
      #workskin .preface .module,
      #workskin .preface blockquote.userstuff {
        margin: 8px 0 !important;
        padding: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        border: none !important;
      }

      #workskin .preface h3.title {
        border-bottom: none !important;
        font-size: 14px !important;
        color: var(--ao3-accent) !important;
        margin-bottom: 4px !important;
      }

      #chapters, #chapters .userstuff, div.userstuff {
        font-family: var(--ao3-font) !important;
        font-size: var(--ao3-font-size) !important;
        line-height: 1.9 !important;
        color: var(--ao3-text) !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      #chapters p, div.userstuff p {
        margin: 0 0 1.15em 0 !important;
        text-align: justify !important;
      }

      /* Buttons & Action bars (Entire Work, Next Chapter, Kudos, Edit Your Search) */
      ul.work.navigation.actions, ul.actions, p.actions, span.actions {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 6px !important;
        margin: 8px 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .actions a, .actions input[type="submit"], .actions button,
      input[type="submit"], button.action {
        background: var(--ao3-pill-bg) !important;
        color: var(--ao3-text) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 12px !important;
        padding: 6px 12px !important;
        font-size: 12.5px !important;
        font-weight: 600 !important;
        box-shadow: none !important;
      }

      /* Instant Page Flip Mode (Zero Animation!) */
      body.__ao3_page_mode, body.__ao3_page_mode * {
        transition: none !important;
        animation: none !important;
        scroll-behavior: auto !important;
      }
    `;
  }

  function ensureBgLayers() {
    if (!document.body) return;
    if (!document.getElementById("__ao3_bg_layer")) {
      const bg = document.createElement("div");
      bg.id = "__ao3_bg_layer";
      const ov = document.createElement("div");
      ov.id = "__ao3_bg_overlay";
      document.body.prepend(ov);
      document.body.prepend(bg);
    }
  }

  // Extract logged-in username from AO3 native header before hiding it
  function getLoggedInUser() {
    const greeting = document.querySelector("#greeting p.icon a, #greeting .user a");
    if (greeting && greeting.textContent) {
      return greeting.textContent.trim();
    }
    return "";
  }

  // Build Custom App Header replacing AO3's red header
  function buildCustomHeader() {
    if (!document.body || document.getElementById("__ao3_custom_header")) return;
    const username = getLoggedInUser();
    const header = document.createElement("div");
    header.id = "__ao3_custom_header";
    header.style.cssText = "max-width:680px;margin:0 auto;padding:10px 12px 4px 12px;box-sizing:border-box;position:relative;z-index:9990;";

    header.innerHTML = `
      <!-- Top Row: 1:1 matching screenshot 1000130110.jpg -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div style="display:flex;align-items:center;gap:10px;">
          <button id="__ao3_btn_menu" style="width:42px;height:42px;border-radius:15px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);font-size:18px;font-weight:700;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,0.05);">
            ☰
          </button>
          <div>
            <div style="font-size:17px;font-weight:800;color:var(--ao3-text);letter-spacing:-0.2px;">
              AO3 • 专属阅读
            </div>
            <div style="font-size:11.5px;color:var(--ao3-subtext);">
              ${username ? `你好，${username} • 专属定制版` : "去红定制版 • 沉浸阅读模式"}
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;">
          <button id="__ao3_mode_btn" style="height:40px;padding:0 14px;border-radius:999px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);font-size:12.5px;font-weight:700;box-shadow:0 4px 14px rgba(0,0,0,0.05);">
            ${config.readingMode === "page" ? "翻页模式" : "滑动模式"}
          </button>
          <button id="__ao3_open_settings" title="阅读与背景设置" style="width:42px;height:42px;border-radius:15px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(0,0,0,0.05);">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18.37 2.63 14 7l-1.59-1.59a2 2 0 0 0-2.82 0L8 7l9 9 1.59-1.59a2 2 0 0 0 0-2.82L17 10l4.37-4.37a2.12 2.12 0 1 0-3-3Z"/>
              <path d="M9 8c-2 3-4 3.5-7 4l8 10c2-1 6-5 6-7"/>
              <path d="M14.5 17.5 3.5 15"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Second Row: Clean Rounded Search Bar & Quick Navigation Pills -->
      <div id="__ao3_nav_drawer" style="background:var(--ao3-card-bg);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid var(--ao3-border);border-radius:20px;padding:12px;margin-bottom:6px;box-shadow:0 6px 20px rgba(0,0,0,0.04);">
        <form action="/works/search" method="get" style="display:flex;gap:8px;margin:0 0 10px 0;">
          <input type="text" name="work_search[query]" placeholder="搜索同人圈、角色、CP或关键词..." style="flex:1;height:38px;padding:0 14px;border-radius:12px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:13.5px;outline:none;" />
          <button type="submit" style="height:38px;padding:0 16px;border-radius:12px;border:none;background:var(--ao3-accent);color:#fff;font-size:13px;font-weight:700;">
            搜索
          </button>
        </form>
        <div style="display:flex;gap:6px;overflow-x:auto;padding-bottom:2px;font-size:12px;font-weight:600;white-space:nowrap;">
          <a href="/" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">🏠 首页</a>
          <a href="/media" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">✨ 同人圈</a>
          <a href="/works/search" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">🔍 高级搜索</a>
          ${username ? `<a href="/users/${username}/bookmarks" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">❤️ 我的收藏</a>` : ""}
          ${username ? `<a href="/users/${username}/readings" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">🕒 阅读历史</a>` : ""}
          ${username ? `<a href="/users/${username}" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">👤 个人主页</a>` : `<a href="/users/login" style="padding:6px 12px;border-radius:10px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);">🔑 登录账号</a>`}
        </div>
      </div>
    `;

    document.body.prepend(header);

    // On work reading pages (#workskin exists), auto-collapse the search bar drawer so story text starts right at the top
    const navDrawer = header.querySelector("#__ao3_nav_drawer");
    if (document.getElementById("workskin")) {
      navDrawer.style.display = "none";
    }

    header.querySelector("#__ao3_btn_menu").addEventListener("click", () => {
      navDrawer.style.display = navDrawer.style.display === "none" ? "block" : "none";
    });

    header.querySelector("#__ao3_mode_btn").addEventListener("click", function() {
      config.readingMode = config.readingMode === "scroll" ? "page" : "scroll";
      this.textContent = config.readingMode === "page" ? "翻页模式" : "滑动模式";
      saveConfig();
      applyAll();
    });

    header.querySelector("#__ao3_open_settings").addEventListener("click", () => {
      const modal = document.getElementById("__ao3_settings_modal");
      if (modal) modal.style.display = "flex";
    });
  }

  // Enhance Search Blurb Cards & Work Meta Box
  function enhanceCardsAndMeta() {
    // 1. Search Result / Blurb Cards
    const blurbs = document.querySelectorAll("li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group");
    blurbs.forEach(card => {
      if (card.querySelector(".__ao3_card_toggle")) return;
      const toggle = document.createElement("div");
      toggle.className = "__ao3_card_toggle";
      toggle.textContent = "点击展开全部标签与简介 ▾";
      const doToggle = function(e) {
        e.stopPropagation();
        const expanded = card.classList.toggle("__ao3_expanded");
        toggle.textContent = expanded ? "收起部分内容 ▴" : "点击展开全部标签与简介 ▾";
      };
      toggle.addEventListener("click", doToggle);
      const summary = card.querySelector("blockquote.userstuff.summary");
      if (summary) summary.addEventListener("click", doToggle);
      card.appendChild(toggle);
    });

    // 2. Work Reading Page: Auto-collapse the giant top metadata table (dl.work.meta.group)
    const workMeta = document.querySelector("dl.work.meta.group");
    if (workMeta && !workMeta.querySelector("#__ao3_meta_toggle")) {
      const toggleBar = document.createElement("div");
      toggleBar.id = "__ao3_meta_toggle";
      toggleBar.style.cssText = "display:flex;align-items:center;justify-content:space-between;cursor:pointer;font-size:13px;font-weight:700;color:var(--ao3-accent);";
      toggleBar.innerHTML = `<span>📋 作品标签与统计详情（点击展开）</span><span id="__ao3_meta_arrow">▾</span>`;
      toggleBar.addEventListener("click", () => {
        const open = workMeta.classList.toggle("__ao3_meta_open");
        toggleBar.querySelector("#__ao3_meta_arrow").textContent = open ? "▴" : "▾";
        toggleBar.querySelector("span").textContent = open ? "📋 收起作品标签与统计详情" : "📋 作品标签与统计详情（点击展开）";
      });
      workMeta.prepend(toggleBar);
    }
  }

  function translateDOM() {
    if (!config.zhTranslate || !document.body) return;

    // Translate submit buttons
    document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(btn => {
      const val = (btn.value || "").trim();
      if (ZH_DICT[val]) btn.value = ZH_DICT[val];
    });

    // Translate text nodes
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      const raw = node.nodeValue.trim();
      if (!raw) continue;
      if (ZH_DICT[raw]) {
        node.nodeValue = node.nodeValue.replace(raw, ZH_DICT[raw]);
      } else if (raw.startsWith("You searched for:")) {
        node.nodeValue = raw.replace("You searched for:", "当前搜索：").replace("sort by:", "排序：").replace("best match", "最佳匹配").replace("descending", "降序");
      } else if (raw.endsWith(" Found")) {
        node.nodeValue = "共找到 " + raw.replace(" Found", "") + " 篇作品";
      } else if (raw.startsWith("Browse fandoms by media")) {
        node.nodeValue = "按分类浏览同人圈，点进感兴趣的分类即可按作品热度筛选：";
      }
    }
  }

  // Instant No-Animation Page Turn Controller
  window.__ao3TurnPage = function(dir) {
    const step = Math.floor(window.innerHeight * 0.86);
    const targetY = Math.max(0, window.scrollY + (dir === "next" ? step : -step));
    window.scrollTo(0, targetY);
    updatePageIndicator();
  };

  window.__ao3VolumeKey = function(dir) {
    window.__ao3TurnPage(dir);
  };

  function updatePageIndicator() {
    const bar = document.getElementById("__ao3_page_status");
    if (!bar) return;
    const step = Math.max(1, Math.floor(window.innerHeight * 0.86));
    const totalHeight = Math.max(step, document.documentElement.scrollHeight - window.innerHeight);
    const totalPages = Math.max(1, Math.ceil(totalHeight / step) + 1);
    const currentPage = Math.min(totalPages, Math.floor(window.scrollY / step) + 1);
    bar.textContent = `无动画翻页模式 • 第 ${currentPage} / ${totalPages} 页（点击左/右侧或按音量键翻页）`;
  }

  function setupPageFlipOverlay() {
    if (!document.body) return;
    let overlay = document.getElementById("__ao3_tap_zones");
    let statusBar = document.getElementById("__ao3_page_status");

    if (config.readingMode === "page") {
      document.body.classList.add("__ao3_page_mode");
      if (!overlay) {
        overlay = document.createElement("div");
        overlay.id = "__ao3_tap_zones";
        overlay.style.cssText = "position:fixed;inset:64px 0 40px 0;z-index:9980;display:flex;pointer-events:none;";
        overlay.innerHTML = `
          <div id="__ao3_tap_left" style="width:32%;height:100%;pointer-events:auto;"></div>
          <div style="width:36%;height:100%;pointer-events:none;"></div>
          <div id="__ao3_tap_right" style="width:32%;height:100%;pointer-events:auto;"></div>
        `;
        document.body.appendChild(overlay);
        overlay.querySelector("#__ao3_tap_left").addEventListener("click", () => window.__ao3TurnPage("prev"));
        overlay.querySelector("#__ao3_tap_right").addEventListener("click", () => window.__ao3TurnPage("next"));
      }
      if (!statusBar) {
        statusBar = document.createElement("div");
        statusBar.id = "__ao3_page_status";
        statusBar.style.cssText = "position:fixed;bottom:0;left:0;right:0;height:34px;z-index:9985;background:var(--ao3-card-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-top:1px solid var(--ao3-border);display:flex;align-items:center;justify-content:center;font-size:11.5px;color:var(--ao3-subtext);font-weight:600;";
        document.body.appendChild(statusBar);
      }
      overlay.style.display = "flex";
      statusBar.style.display = "flex";
      updatePageIndicator();
    } else {
      document.body.classList.remove("__ao3_page_mode");
      if (overlay) overlay.style.display = "none";
      if (statusBar) statusBar.style.display = "none";
    }
  }

  function buildSettingsModal() {
    if (!document.body || document.getElementById("__ao3_settings_modal")) return;
    const modal = document.createElement("div");
    modal.id = "__ao3_settings_modal";
    modal.style.cssText = "position:fixed;inset:0;z-index:100000;background:rgba(20,16,28,0.45);display:none;align-items:flex-end;justify-content:center;";
    modal.innerHTML = `
      <div style="width:100%;max-width:480px;max-height:88vh;overflow-y:auto;background:#fbfafc;border-radius:28px 28px 0 0;padding:22px 20px 26px;color:#2c2638;box-shadow:0 -8px 32px rgba(0,0,0,0.18);font-family:sans-serif;box-sizing:border-box;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <div style="font-size:20px;font-weight:800;">阅读设置</div>
          <button id="__ao3_close_modal" style="width:36px;height:36px;border-radius:12px;border:1px solid #e6e2ec;background:#fff;font-size:16px;color:#555;">✕</button>
        </div>
        <div style="font-size:12px;color:#8c849c;margin-bottom:16px;">字号與字体在所有页面共用；不会改动作品内容。</div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">正文字号 • <span id="__ao3_fs_val">${config.fontSize}</span> px</div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
          <button id="__ao3_fs_dec" style="width:44px;height:38px;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A-</button>
          <input id="__ao3_fs_range" type="range" min="13" max="26" value="${config.fontSize}" style="flex:1;accent-color:#6b5e82;" />
          <button id="__ao3_fs_inc" style="width:44px;height:38px;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A+</button>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:6px;">正文字体</div>
        <select id="__ao3_font_sel" style="width:100%;padding:11px 14px;border-radius:14px;border:1px solid #e2dde9;background:#fff;font-size:14px;color:#2c2638;margin-bottom:14px;">
          <option value="system">系统默认字体（默认）</option>
          <option value="song">飞花宋体 / 思源宋体</option>
          <option value="kai">霞鹜文楷 / 传统楷体</option>
          <option value="hei">柔和黑体 / 无衬线</option>
        </select>

        <div id="__ao3_preview_box" style="padding:16px;border-radius:16px;border:1px solid #e2dde9;margin-bottom:16px;line-height:1.75;">
          浮光落在纸页上。他放下书，轻声说：<br>“不着急，慢慢读。”
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">阅读翻页方式</div>
        <div style="display:flex;gap:8px;margin-bottom:16px;">
          <button id="__ao3_set_scroll" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">上下滑动</button>
          <button id="__ao3_set_page" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">左右翻页(无动画)</button>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">背景颜色与相册壁纸</div>
        <div style="display:flex;gap:10px;align-items:center;margin-bottom:12px;flex-wrap:wrap;" id="__ao3_preset_row"></div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">色相</span>
          <input id="__ao3_hue" type="range" min="0" max="360" value="${config.hue}" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">浓淡</span>
          <input id="__ao3_sat" type="range" min="0" max="80" value="${config.sat}" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">明暗</span>
          <input id="__ao3_light" type="range" min="12" max="97" value="${config.light}" style="flex:1;" />
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:13px;color:#6e667e;">
          <span style="width:72px;">背景透明度</span>
          <input id="__ao3_opacity" type="range" min="20" max="100" value="${config.bgOpacity}" style="flex:1;" />
          <span id="__ao3_op_val" style="width:38px;text-align:right;">${config.bgOpacity}%</span>
        </div>

        <div style="display:flex;gap:10px;margin-bottom:18px;">
          <label style="flex:1;padding:11px;border-radius:12px;border:1px dashed #b8aed0;background:#f5f2fa;color:#524668;font-size:13px;font-weight:700;text-align:center;cursor:pointer;">
            🖼️ 选择手机相册背景图
            <input id="__ao3_bg_file" type="file" accept="image/*" style="display:none;" />
          </label>
          <button id="__ao3_clear_bg" style="padding:11px 14px;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-size:13px;color:#666;">清除背景图</button>
        </div>

        <div style="display:flex;gap:12px;">
          <button id="__ao3_reset_btn" style="flex:1;padding:13px;border-radius:14px;border:1px solid #dcd6e8;background:#fff;font-size:15px;font-weight:700;color:#554d66;">恢复默认</button>
          <button id="__ao3_save_btn" style="flex:1;padding:13px;border-radius:14px;border:none;background:#3b3746;font-size:15px;font-weight:700;color:#fff;">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const presetRow = modal.querySelector("#__ao3_preset_row");
    PRESETS.forEach(p => {
      const btn = document.createElement("button");
      btn.title = p.name;
      btn.style.cssText = `width:32px;height:32px;border-radius:50%;border:2px solid #b5abc9;background:hsl(${p.h},${p.s}%,${p.l}%);cursor:pointer;`;
      btn.addEventListener("click", () => {
        config.hue = p.h;
        config.sat = p.s;
        config.light = p.l;
        modal.querySelector("#__ao3_hue").value = p.h;
        modal.querySelector("#__ao3_sat").value = p.s;
        modal.querySelector("#__ao3_light").value = p.l;
        applyAll();
        syncPreview();
      });
      presetRow.appendChild(btn);
    });

    function syncPreview() {
      const box = modal.querySelector("#__ao3_preview_box");
      box.style.fontSize = config.fontSize + "px";
      box.style.fontFamily = getFontStack(config.fontFamily);
      box.style.background = `hsl(${config.hue}, ${config.sat}%, ${config.light}%)`;
      box.style.color = config.light < 36 ? "#f2eef8" : "#2c2638";
    }

    modal.querySelector("#__ao3_close_modal").addEventListener("click", () => modal.style.display = "none");
    modal.querySelector("#__ao3_save_btn").addEventListener("click", () => {
      saveConfig();
      modal.style.display = "none";
    });
    modal.querySelector("#__ao3_reset_btn").addEventListener("click", () => {
      config = Object.assign({}, DEFAULT_CONFIG);
      saveConfig();
      applyAll();
      syncPreview();
    });

    modal.querySelector("#__ao3_fs_range").addEventListener("input", e => {
      config.fontSize = parseInt(e.target.value, 10);
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_fs_dec").addEventListener("click", () => {
      config.fontSize = Math.max(13, config.fontSize - 1);
      modal.querySelector("#__ao3_fs_range").value = config.fontSize;
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_fs_inc").addEventListener("click", () => {
      config.fontSize = Math.min(26, config.fontSize + 1);
      modal.querySelector("#__ao3_fs_range").value = config.fontSize;
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_font_sel").value = config.fontFamily;
    modal.querySelector("#__ao3_font_sel").addEventListener("change", e => {
      config.fontFamily = e.target.value;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_hue").addEventListener("input", e => {
      config.hue = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_sat").addEventListener("input", e => {
      config.sat = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_light").addEventListener("input", e => {
      config.light = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_opacity").addEventListener("input", e => {
      config.bgOpacity = parseInt(e.target.value, 10);
      modal.querySelector("#__ao3_op_val").textContent = config.bgOpacity + "%";
      applyAll();
    });
    modal.querySelector("#__ao3_set_scroll").addEventListener("click", () => {
      config.readingMode = "scroll";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "滑动模式";
      saveConfig();
      applyAll();
    });
    modal.querySelector("#__ao3_set_page").addEventListener("click", () => {
      config.readingMode = "page";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "翻页模式";
      saveConfig();
      applyAll();
    });
    modal.querySelector("#__ao3_bg_file").addEventListener("change", e => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function(ev) {
        config.bgImage = ev.target.result;
        saveConfig();
        applyAll();
      };
      reader.readAsDataURL(file);
    });
    modal.querySelector("#__ao3_clear_bg").addEventListener("click", () => {
      config.bgImage = "";
      saveConfig();
      applyAll();
    });

    syncPreview();
  }

  function applyAll() {
    ensureViewportMeta();
    injectStyles();
    if (!document.body) return;
    ensureBgLayers();
    buildCustomHeader();
    enhanceCardsAndMeta();
    translateDOM();
    setupPageFlipOverlay();
    buildSettingsModal();
  }

  window.__ao3ApplyAll = applyAll;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyAll);
  } else {
    applyAll();
  }
})();
