(function() {
  if (window.__ao3EnhancerV32Loaded) {
    if (window.__ao3ApplyAll) window.__ao3ApplyAll();
    return;
  }
  window.__ao3EnhancerV32Loaded = true;

  const DEFAULT_CONFIG = {
    fontSize: 17,
    fontFamily: "system",
    hue: 262,
    sat: 28,
    light: 90,
    bgImage: "",
    bgOpacity: 82,
    readingMode: "scroll", // "scroll" or "page"
    zhTranslate: true
  };

  let config = Object.assign({}, DEFAULT_CONFIG);
  try {
    const saved = localStorage.getItem("__ao3_custom_reader_cfg_v3");
    if (saved) config = Object.assign({}, DEFAULT_CONFIG, JSON.parse(saved));
  } catch (e) {}

  try {
    const savedBg = localStorage.getItem("__ao3_custom_reader_bg_v1");
    if (savedBg) config.bgImage = savedBg;
  } catch (e) {}

  function saveConfig() {
    try {
      const copy = Object.assign({}, config, { bgImage: "" });
      localStorage.setItem("__ao3_custom_reader_cfg_v3", JSON.stringify(copy));
      if (config.bgImage) {
        localStorage.setItem("__ao3_custom_reader_bg_v1", config.bgImage);
      } else {
        localStorage.removeItem("__ao3_custom_reader_bg_v1");
      }
    } catch (e) {}
  }

  const PRESETS = [
    { name: "雾紫", h: 262, s: 28, l: 90 },
    { name: "丁香", h: 258, s: 45, l: 84 },
    { name: "烟粉", h: 310, s: 26, l: 88 },
    { name: "暮山紫", h: 256, s: 22, l: 76 },
    { name: "云水蓝", h: 220, s: 16, l: 92 },
    { name: "羊皮纸", h: 42, s: 38, l: 93 },
    { name: "夜间黑", h: 240, s: 14, l: 15 }
  ];

  const ZH_DICT = {
    "Fandoms": "同人圈",
    "Browse": "浏览",
    "Search": "搜索",
    "About": "关于",
    "Log In": "登录",
    "Log Out": "退出",
    "Post": "发布",
    "New Work": "发布新作",
    "Import Work": "导入作品",
    "My Dashboard": "个人主页",
    "Dashboard": "主页",
    "Profile": "个人资料",
    "Preferences": "偏好设置",
    "Skins": "网站皮肤",
    "Works": "作品",
    "Drafts": "草稿",
    "Series": "系列",
    "Bookmarks": "收藏书签",
    "Collections": "合集",
    "Inbox": "收件箱",
    "Statistics": "数据统计",
    "History": "阅读历史",
    "Subscriptions": "我的订阅",
    "Find your favorites": "探索你喜欢的同人圈",
    "All Fandoms": "全部同人圈",
    "Anime & Manga": "动漫与漫画 (ACG)",
    "Books & Literature": "书籍与文学",
    "Cartoons & Comics & Graphic Novels": "卡通、美漫与绘本",
    "Celebrities & Real People": "真人影视与明星 (RPS)",
    "Movies": "电影专区",
    "Music & Bands": "音乐与乐队",
    "Other Media": "其他衍生媒体",
    "Theater": "戏剧与音乐剧",
    "TV Shows": "电视剧集",
    "Video Games": "电子游戏",
    "Uncategorized Fandoms": "未分类同人圈",
    "News": "站内公告",
    "All News": "全部公告",
    "Search Results": "搜索结果",
    "Edit Your Search": "修改搜索条件",
    "Sort and Filter": "排序与筛选",
    "Sort by": "排序方式",
    "Best Match": "最佳匹配",
    "Author": "作者",
    "Title": "标题",
    "Date Posted": "发布日期",
    "Date Updated": "更新日期",
    "Word Count": "字数统计",
    "Hits": "点击量",
    "Kudos": "点赞数",
    "Comments": "评论数",
    "Bookmarks:": "收藏：",
    "Collections:": "合集：",
    "Comments:": "评论：",
    "Kudos:": "点赞：",
    "Hits:": "点击：",
    "Words:": "字数：",
    "Chapters:": "章节：",
    "Language:": "语言：",
    "Series:": "系列：",
    "Published:": "发布：",
    "Updated:": "更新：",
    "Completed:": "完结：",
    "Status:": "状态：",
    "Rating": "分级",
    "Rating:": "分级：",
    "Archive Warning": "归档警告",
    "Archive Warnings": "归档警告",
    "Archive Warning:": "归档警告：",
    "Archive Warnings:": "归档警告：",
    "Category": "性向分类",
    "Categories": "性向分类",
    "Category:": "性向分类：",
    "Categories:": "性向分类：",
    "Fandom": "原作圈",
    "Fandom:": "原作圈：",
    "Fandoms:": "原作圈：",
    "Relationship": "配对/CP",
    "Relationships": "配对/CP",
    "Relationship:": "配对/CP：",
    "Relationships:": "配对/CP：",
    "Character": "角色",
    "Characters": "角色",
    "Character:": "角色：",
    "Characters:": "角色：",
    "Additional Tags": "附加标签",
    "Additional Tags:": "附加标签：",
    "Stats": "数据统计",
    "Stats:": "统计：",
    "Summary": "作品简介",
    "Summary:": "作品简介",
    "Notes": "作者的话",
    "Notes:": "作者的话",
    "Work Text": "正文内容",
    "Work Text:": "正文内容",
    "Entire Work": "全文阅读",
    "Chapter by Chapter": "分章阅读",
    "Chapter Index": "章节目录",
    "Next Chapter →": "下一章 →",
    "← Previous Chapter": "← 上一章",
    "Kudos ♥": "♥ 点赞",
    "Bookmark": "收藏",
    "Subscribe": "订阅",
    "Download": "下载",
    "Share": "分享",
    "Top": "返回顶部",
    "No Archive Warnings Apply": "无归档警告",
    "Creator Chose Not To Use Archive Warnings": "作者未标注归档警告",
    "Graphic Depictions Of Violence": "含暴力描写",
    "Major Character Death": "主要角色死亡",
    "Underage": "未成年相关警告",
    "Underage Sex": "未成年相关警告",
    "Rape/Non-Con": "非自愿警告",
    "General Audiences": "全年龄 (G)",
    "Teen And Up Audiences": "青少年及以上 (T)",
    "Mature": "成熟级 (M)",
    "Explicit": "限制级 (E)",
    "Not Rated": "未分级"
  };

  const MONTH_MAP = {
    jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06",
    jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12"
  };

  function translateTagText(str) {
    const t = (str || "").trim();
    return ZH_DICT[t] || t;
  }

  function convertDateString(str) {
    if (!str) return "";
    return str.replace(/\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s*(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+(\d{4})(?:\s+(\d{1,2}:\d{2})\s*([AP]M)?\s*(?:UTC|EST|EDT|PST)?)?/gi, function(_, d, m, y, time, ampm) {
      const mm = MONTH_MAP[m.toLowerCase().slice(0, 3)] || "01";
      const dd = String(d).padStart(2, "0");
      if (time) {
        let [hh, min] = time.split(":");
        let hNum = parseInt(hh, 10);
        if (ampm && ampm.toUpperCase() === "PM" && hNum < 12) hNum += 12;
        if (ampm && ampm.toUpperCase() === "AM" && hNum === 12) hNum = 0;
        return `${y}-${mm}-${dd} ${String(hNum).padStart(2, "0")}:${min}`;
      }
      return `${y}-${mm}-${dd}`;
    }).trim();
  }

  function getFontStack(key) {
    if (key === "song") return "'Noto Serif SC', 'Source Han Serif SC', 'Songti SC', 'SimSun', serif";
    if (key === "kai") return "'LXGW WenKai', 'Kaiti SC', 'STKaiti', 'KaiTi', serif";
    if (key === "hei") return "'PingFang SC', 'HarmonyOS Sans SC', 'Microsoft YaHei', sans-serif";
    return "-apple-system, BlinkMacSystemFont, 'PingFang SC', 'Segoe UI', Roboto, sans-serif";
  }

  function ensureViewportMeta() {
    if (!document.head) return;
    let vp = document.querySelector('meta[name="viewport"]');
    if (!vp) {
      vp = document.createElement("meta");
      vp.name = "viewport";
      document.head.appendChild(vp);
    }
    vp.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no";
  }

  function injectStyles() {
    if (!document.head) return;
    let styleEl = document.getElementById("__ao3_custom_style_v32");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "__ao3_custom_style_v32";
      document.head.appendChild(styleEl);
    }

    const isDark = config.light < 36;
    const textColor = isDark ? "#f0ecf8" : "#2b2538";
    const subTextColor = isDark ? "#aba2be" : "#746b86";
    const accentColor = `hsl(${config.hue}, ${Math.min(config.sat + 30, 72)}%, ${isDark ? 72 : 43}%)`;
    const accentSoft = isDark
      ? `hsla(${config.hue}, ${Math.min(config.sat + 25, 65)}%, 62%, 0.22)`
      : `hsla(${config.hue}, ${Math.min(config.sat + 25, 65)}%, 48%, 0.12)`;
    const pageBgHsl = `hsl(${config.hue}, ${config.sat}%, ${config.light}%)`;
    const cardAlpha = Math.max(0.20, Math.min(0.98, config.bgOpacity / 100));
    const cardBg = isDark
      ? `rgba(34, 30, 44, ${cardAlpha})`
      : `rgba(255, 255, 255, ${cardAlpha})`;
    const pillBg = isDark
      ? `rgba(48, 42, 62, 0.85)`
      : `rgba(255, 255, 255, 0.90)`;
    const borderCol = isDark
      ? "rgba(255, 255, 255, 0.12)"
      : "rgba(165, 152, 195, 0.24)";
    const fontStack = getFontStack(config.fontFamily);
    const baseSize = config.fontSize;

    styleEl.textContent = `
      :root {
        --ao3-bg: ${pageBgHsl};
        --ao3-card-bg: ${cardBg};
        --ao3-pill-bg: ${pillBg};
        --ao3-border: ${borderCol};
        --ao3-text: ${textColor};
        --ao3-subtext: ${subTextColor};
        --ao3-accent: ${accentColor};
        --ao3-accent-soft: ${accentSoft};
        --ao3-font: ${fontStack};
        --ao3-base-size: ${baseSize}px;
      }

      *, *:focus, *:active, button, input, select, a {
        outline: none !important;
        -webkit-tap-highlight-color: transparent !important;
      }

      #header, #footer {
        display: none !important;
      }

      html, body, #outer, #inner {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ao3-font) !important;
        font-size: var(--ao3-base-size) !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        overflow-x: hidden !important;
      }

      #main {
        background: transparent !important;
        color: var(--ao3-text) !important;
        font-family: var(--ao3-font) !important;
        font-size: var(--ao3-base-size) !important;
        padding: 6px 12px 80px 12px !important;
        margin: 0 auto !important;
        max-width: 680px !important;
        box-sizing: border-box !important;
      }

      /* When Page Flip Mode is active on a work page, completely hide #__ao3_custom_header and #main so there is ZERO overlap at the top! */
      body.__ao3_paged_active #__ao3_custom_header,
      body.__ao3_paged_active #main {
        display: none !important;
      }

      #__ao3_bg_layer {
        position: fixed !important;
        inset: 0 !important;
        z-index: -2 !important;
        background-color: var(--ao3-bg) !important;
        background-image: ${config.bgImage ? `url("${config.bgImage}")` : "none"} !important;
        background-size: cover !important;
        background-position: center !important;
        background-repeat: no-repeat !important;
      }

      #__ao3_bg_overlay {
        position: fixed !important;
        inset: 0 !important;
        z-index: -1 !important;
        background-color: var(--ao3-bg) !important;
        opacity: ${config.bgImage ? (100 - config.bgOpacity) / 100 : 1} !important;
        pointer-events: none !important;
      }

      h1, h2, h3, h4, h5, h6,
      .heading, .splash .module h3,
      .splash .browse li a:before,
      span.symbol, .question {
        color: var(--ao3-accent) !important;
        border-bottom-color: var(--ao3-border) !important;
        font-family: var(--ao3-font) !important;
      }

      h2.heading {
        font-size: calc(var(--ao3-base-size) * 1.12) !important;
        margin: 6px 4px 10px 4px !important;
      }

      a, a:link, a:visited, a:hover, a:active, abbr {
        color: var(--ao3-text) !important;
        border-bottom: none !important;
        text-decoration: none !important;
        background: transparent !important;
      }

      /* Home Page (.splash) clean cards */
      .splash .module, .splash .browse, .splash .news {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 22px !important;
        padding: 18px 16px !important;
        margin: 0 0 14px 0 !important;
        box-shadow: 0 8px 24px rgba(42, 32, 68, 0.05) !important;
        width: 100% !important;
        float: none !important;
        box-sizing: border-box !important;
      }

      .splash .browse p {
        font-size: calc(var(--ao3-base-size) * 0.90) !important;
        line-height: 1.6 !important;
        color: var(--ao3-subtext) !important;
        margin: 6px 0 12px 0 !important;
      }

      .splash .browse ul {
        display: grid !important;
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 10px !important;
        padding: 0 !important;
        margin: 10px 0 0 0 !important;
      }

      .splash .browse li {
        width: 100% !important;
        float: none !important;
        margin: 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .splash .browse li a {
        display: flex !important;
        align-items: center !important;
        min-height: 44px !important;
        padding: 10px 12px !important;
        background: var(--ao3-pill-bg) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 14px !important;
        font-size: calc(var(--ao3-base-size) * 0.86) !important;
        font-weight: 600 !important;
        line-height: 1.35 !important;
        color: var(--ao3-text) !important;
        box-sizing: border-box !important;
      }

      /* Search Results List Reset */
      ol.work.index.group, ul.index.group, ol.bookmark.index.group {
        padding: 0 !important;
        margin: 0 !important;
        list-style: none !important;
      }

      /* Kaelis Custom Card (1:1 identical to Image 1: image_e87b5d.png!) */
      li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border-radius: 22px !important;
        border: 1px solid var(--ao3-border) !important;
        padding: 18px 18px 14px 18px !important;
        margin: 14px 0 !important;
        box-shadow: 0 8px 26px rgba(42, 32, 68, 0.05) !important;
        position: relative !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
      }

      /* Work Reading View (#workskin, #chapters) */
      dl.work.meta.group {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(14px) !important;
        -webkit-backdrop-filter: blur(14px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 20px !important;
        padding: 14px 16px !important;
        margin: 0 0 12px 0 !important;
        box-shadow: none !important;
      }

      dl.work.meta.group:not(.__ao3_meta_open) > dt,
      dl.work.meta.group:not(.__ao3_meta_open) > dd {
        display: none !important;
      }

      #workskin {
        background: var(--ao3-card-bg) !important;
        backdrop-filter: blur(16px) !important;
        -webkit-backdrop-filter: blur(16px) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 24px !important;
        padding: 20px 18px !important;
        margin: 0 !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        box-shadow: 0 8px 28px rgba(42, 32, 68, 0.06) !important;
      }

      #workskin .preface,
      #workskin .preface .module,
      #workskin .preface blockquote.userstuff {
        margin: 8px 0 !important;
        padding: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        border: none !important;
      }

      #workskin .preface h3.title {
        border-bottom: none !important;
        font-size: calc(var(--ao3-base-size) * 0.92) !important;
        color: var(--ao3-accent) !important;
        margin-bottom: 4px !important;
      }

      #chapters, #chapters .userstuff, div.userstuff {
        font-family: var(--ao3-font) !important;
        font-size: var(--ao3-base-size) !important;
        line-height: 1.9 !important;
        color: var(--ao3-text) !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      #chapters p, div.userstuff p {
        font-size: var(--ao3-base-size) !important;
        line-height: 1.9 !important;
        margin: 0 0 1.1em 0 !important;
        text-align: justify !important;
      }

      ul.work.navigation.actions, ul.actions, p.actions, span.actions {
        display: flex !important;
        flex-wrap: wrap !important;
        gap: 6px !important;
        margin: 8px 0 !important;
        padding: 0 !important;
        list-style: none !important;
      }

      .actions a, .actions input[type="submit"], .actions button,
      input[type="submit"], button.action {
        background: var(--ao3-pill-bg) !important;
        color: var(--ao3-text) !important;
        border: 1px solid var(--ao3-border) !important;
        border-radius: 12px !important;
        padding: 7px 14px !important;
        font-size: calc(var(--ao3-base-size) * 0.80) !important;
        font-weight: 600 !important;
        box-shadow: none !important;
      }

      /* Settings Modal Styling */
      #__ao3_settings_modal .__ao3_color_dot {
        width: 36px !important;
        height: 36px !important;
        min-width: 36px !important;
        max-width: 36px !important;
        min-height: 36px !important;
        max-height: 36px !important;
        padding: 0 !important;
        margin: 0 !important;
        border-radius: 50% !important;
        aspect-ratio: 1 / 1 !important;
        flex: 0 0 36px !important;
        display: inline-block !important;
        box-sizing: border-box !important;
        cursor: pointer !important;
        box-shadow: 0 2px 6px rgba(0,0,0,0.08) !important;
      }

      #__ao3_settings_modal input[type="range"] {
        -webkit-appearance: none !important;
        appearance: none !important;
        height: 10px !important;
        border-radius: 999px !important;
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
      }

      #__ao3_settings_modal #__ao3_hue {
        background: linear-gradient(to right, #e57373, #ffb74d, #fff176, #81c784, #64b5f6, #9575cd, #f06292) !important;
      }

      #__ao3_settings_modal #__ao3_sat {
        background: linear-gradient(to right, #e6e4ea, #b39ddb) !important;
      }

      #__ao3_settings_modal #__ao3_light {
        background: linear-gradient(to right, #2c2638, #b39ddb, #ffffff) !important;
      }

      #__ao3_settings_modal #__ao3_opacity,
      #__ao3_settings_modal #__ao3_fs_range {
        background: #e2dde9 !important;
      }

      #__ao3_settings_modal input[type="range"]::-webkit-slider-thumb {
        -webkit-appearance: none !important;
        appearance: none !important;
        width: 24px !important;
        height: 24px !important;
        border-radius: 50% !important;
        background: #ffffff !important;
        border: 2.5px solid #6b5e82 !important;
        box-shadow: 0 2px 6px rgba(0,0,0,0.18) !important;
      }
    `;
  }

  function ensureBgLayers() {
    if (!document.body) return;
    if (!document.getElementById("__ao3_bg_layer")) {
      const bg = document.createElement("div");
      bg.id = "__ao3_bg_layer";
      const ov = document.createElement("div");
      ov.id = "__ao3_bg_overlay";
      document.body.prepend(ov);
      document.body.prepend(bg);
    }
  }

  function getLoggedInUser() {
    const userLink = document.querySelector('#greeting a[href^="/users/"]');
    if (userLink && userLink.getAttribute("href")) {
      const parts = userLink.getAttribute("href").split("/");
      if (parts[2]) return parts[2].trim();
    }
    const greeting = document.querySelector("#greeting p.icon a, #greeting .user a");
    if (greeting && greeting.textContent) {
      return greeting.textContent
        .replace(/^(你好，|Hi,)\s*/i, "")
        .replace(/!$/, "")
        .trim();
    }
    return "";
  }

  function buildCustomHeader() {
    if (!document.body) return;
    const existing = document.getElementById("__ao3_custom_header");
    if (existing) existing.remove();

    const username = getLoggedInUser();
    const header = document.createElement("div");
    header.id = "__ao3_custom_header";
    header.style.cssText = "max-width:680px;margin:0 auto;padding:12px 12px 4px 12px;box-sizing:border-box;position:relative;z-index:9980;";

    header.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;">
        <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1;">
          <button id="__ao3_btn_menu" style="width:42px;height:42px;flex:0 0 42px;border-radius:14px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);font-size:18px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 4px 12px rgba(0,0,0,0.04);">
            ☰
          </button>
          <div style="min-width:0;flex:1;">
            <div style="font-size:18px;font-weight:800;color:var(--ao3-text);line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
              Kaelis
            </div>
            <div style="font-size:12px;color:var(--ao3-subtext);line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px;">
              ${username ? `@${username} · 专属阅读` : "AO3 专属阅读空间"}
            </div>
          </div>
        </div>

        <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
          <button id="__ao3_mode_btn" style="height:40px;padding:0 14px;border-radius:999px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);font-size:13px;font-weight:700;white-space:nowrap;box-shadow:0 4px 12px rgba(0,0,0,0.04);">
            ${config.readingMode === "page" ? "翻页模式" : "滑动模式"}
          </button>
          <button id="__ao3_open_settings" title="阅读设置" style="width:42px;height:42px;flex:0 0 42px;padding:0;border-radius:14px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);color:var(--ao3-text);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,0.04);">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18.37 2.63 14 7l-1.59-1.59a2 2 0 0 0-2.82 0L8 7l9 9 1.59-1.59a2 2 0 0 0 0-2.82L17 10l4.37-4.37a2.12 2.12 0 1 0-3-3Z"/>
              <path d="M9 8c-2 3-4 3.5-7 4l8 10c2-1 6-5 6-7"/>
              <path d="M14.5 17.5 3.5 15"/>
            </svg>
          </button>
        </div>
      </div>

      <div id="__ao3_nav_drawer" style="background:var(--ao3-card-bg);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid var(--ao3-border);border-radius:20px;padding:12px;margin-bottom:6px;box-shadow:0 6px 20px rgba(0,0,0,0.04);box-sizing:border-box;">
        <form action="/works/search" method="get" style="display:flex;gap:8px;margin:0 0 10px 0;">
          <input type="text" name="work_search[query]" placeholder="搜索同人圈、角色、CP或关键词..." style="flex:1;min-width:0;height:40px;padding:0 14px;border-radius:12px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:14px;" />
          <button type="submit" style="height:40px;padding:0 18px;border-radius:12px;border:none;background:var(--ao3-accent);color:#fff;font-size:13.5px;font-weight:700;flex-shrink:0;">
            搜索
          </button>
        </form>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;font-size:12.5px;font-weight:600;">
          <a href="/" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🏠 首页</a>
          <a href="/media" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">✨ 同人圈</a>
          ${username ? `<a href="/users/${username}/bookmarks" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">❤️ 收藏</a>` : `<a href="/works/search" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🔍 筛选</a>`}
          ${username ? `<a href="/users/${username}/readings" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🕒 历史</a>` : `<a href="/users/login" style="padding:8px 4px;border-radius:11px;background:var(--ao3-pill-bg);border:1px solid var(--ao3-border);text-align:center;white-space:nowrap;">🔑 登录</a>`}
        </div>
      </div>
    `;

    document.body.prepend(header);

    const navDrawer = header.querySelector("#__ao3_nav_drawer");
    if (document.getElementById("workskin")) {
      navDrawer.style.display = "none";
    }

    header.querySelector("#__ao3_btn_menu").addEventListener("click", () => {
      navDrawer.style.display = navDrawer.style.display === "none" ? "block" : "none";
    });

    header.querySelector("#__ao3_mode_btn").addEventListener("click", function() {
      config.readingMode = config.readingMode === "scroll" ? "page" : "scroll";
      this.textContent = config.readingMode === "page" ? "翻页模式" : "滑动模式";
      saveConfig();
      applyAll();
    });

    header.querySelector("#__ao3_open_settings").addEventListener("click", () => {
      const modal = document.getElementById("__ao3_settings_modal");
      if (modal) modal.style.display = "flex";
    });
  }

  // ==================== REBUILD SEARCH CARDS TO MATCH IMAGE 1 (image_e87b5d.png) 1:1 ====================
  function rebuildBlurbCardsToMatchImage1() {
    const blurbs = document.querySelectorAll("li.work.blurb.group, li.bookmark.blurb.group, li.series.blurb.group");
    blurbs.forEach(card => {
      if (card.dataset.kaelisRebuilt === "1") return;

      const titleLink = card.querySelector("h4.heading a:first-child");
      if (!titleLink) return;
      const titleText = titleLink.textContent.trim();
      const workUrl = titleLink.getAttribute("href") || "#";

      const authorLinks = card.querySelectorAll('h4.heading a[rel="author"]');
      let authorHtml = "Anonymous";
      if (authorLinks.length > 0) {
        authorHtml = Array.from(authorLinks).map(a => `<a href="${a.getAttribute("href")}" style="font-weight:600;color:var(--ao3-subtext);">${a.textContent.trim()}</a>`).join(", ");
      }

      const fandomLinks = card.querySelectorAll("h5.fandoms.heading a");
      const fandomText = Array.from(fandomLinks).map(a => a.textContent.trim()).join(" / ") || "";

      const dateEl = card.querySelector("p.datetime");
      const dateStr = dateEl ? convertDateString(dateEl.textContent) : "";

      // Extract CP pill (first relationship tag) and all tags
      const relEls = card.querySelectorAll("ul.tags li.relationships a");
      const cpBadgeText = relEls.length > 0 ? relEls[0].textContent.trim() : "";

      const allTagEls = card.querySelectorAll("ul.tags li a");
      const allTags = [];
      allTagEls.forEach(a => {
        const t = translateTagText(a.textContent);
        const href = a.getAttribute("href") || "#";
        const isRel = a.parentElement && a.parentElement.classList.contains("relationships");
        allTags.push({ text: t, href: href, isRel: isRel });
      });

      // Extract Summary paragraphs & plain text
      const summaryEl = card.querySelector("blockquote.userstuff.summary");
      let summaryFullHtml = "";
      let summaryPlainText = "";
      if (summaryEl) {
        summaryPlainText = (summaryEl.textContent || "").replace(/\s+/g, " ").trim();
        summaryFullHtml = summaryEl.innerHTML.trim();
      }

      // Extract clean stats (Words, Chapters, Kudos, Hits) - NO shaded block!
      const wordsEl = card.querySelector("dd.words");
      const chaptersEl = card.querySelector("dd.chapters");
      const kudosEl = card.querySelector("dd.kudos");
      const hitsEl = card.querySelector("dd.hits");

      const wordsVal = wordsEl ? wordsEl.textContent.trim() : "";
      const chaptersVal = chaptersEl ? chaptersEl.textContent.trim() : "";
      const kudosVal = kudosEl ? kudosEl.textContent.trim() : "";
      const hitsVal = hitsEl ? hitsEl.textContent.trim() : "";

      card.dataset.kaelisRebuilt = "1";
      let isExpanded = false;

      const TAG_LIMIT = 4;
      const SUMMARY_LIMIT = 66;
      const hasMoreTags = allTags.length > TAG_LIMIT;
      const hasMoreSummary = summaryPlainText.length > SUMMARY_LIMIT;
      const canExpand = hasMoreTags || hasMoreSummary;

      function renderCardContent() {
        const shownTags = isExpanded ? allTags : allTags.slice(0, TAG_LIMIT);
        const hiddenTagCount = Math.max(0, allTags.length - TAG_LIMIT);

        let summarySectionHtml = "";
        if (summaryPlainText) {
          if (isExpanded || !hasMoreSummary) {
            summarySectionHtml = `
              <div class="__kaelis_summary_area" style="margin:10px 0 4px 0;font-size:var(--ao3-base-size);line-height:1.72;color:var(--ao3-text);cursor:${canExpand ? "pointer" : "default"};">
                ${summaryFullHtml}
              </div>
            `;
          } else {
            const shortText = summaryPlainText.slice(0, SUMMARY_LIMIT) + "…";
            summarySectionHtml = `
              <div class="__kaelis_summary_area" style="margin:10px 0 4px 0;font-size:var(--ao3-base-size);line-height:1.72;color:var(--ao3-text);cursor:pointer;">
                ${shortText}
              </div>
            `;
          }
        }

        const statsParts = [];
        if (wordsVal) statsParts.push(`<span>字数: ${wordsVal}</span>`);
        if (chaptersVal) statsParts.push(`<span>章节: ${chaptersVal}</span>`);
        if (kudosVal) statsParts.push(`<span>♥ ${kudosVal}</span>`);
        else if (hitsVal) statsParts.push(`<span>点击: ${hitsVal}</span>`);

        card.innerHTML = `
          <!-- Header Row (1:1 like Image 1: Title + Subtitle on left, CP pill on right) -->
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:8px;">
            <div style="min-width:0;flex:1;">
              <a href="${workUrl}" style="display:block;font-size:calc(var(--ao3-base-size)*1.08);font-weight:800;color:var(--ao3-accent);line-height:1.4;">
                ${titleText}
              </a>
              <div style="font-size:calc(var(--ao3-base-size)*0.78);color:var(--ao3-subtext);margin-top:4px;line-height:1.4;">
                作者 ${authorHtml}${fandomText ? ` • ${fandomText}` : ""}${dateStr ? ` • ${dateStr}` : ""}
              </div>
            </div>
            ${cpBadgeText ? `
              <span style="flex-shrink:0;max-width:44%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:4px 11px;border-radius:999px;background:var(--ao3-accent-soft);color:var(--ao3-text);font-size:calc(var(--ao3-base-size)*0.74);font-weight:700;">
                ${cpBadgeText}
              </span>
            ` : ""}
          </div>

          <!-- Tags Pills Row -->
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 6px 0;">
            ${shownTags.map(t => `
              <a href="${t.href}" style="padding:4px 11px;border-radius:10px;background:${t.isRel ? "var(--ao3-accent-soft)" : "var(--ao3-pill-bg)"};border:1px solid var(--ao3-border);color:${t.isRel ? "var(--ao3-accent)" : "var(--ao3-text)"};font-size:calc(var(--ao3-base-size)*0.76);font-weight:${t.isRel ? "700" : "500"};line-height:1.4;">
                ${t.text}
              </a>
            `).join("")}
            ${!isExpanded && hiddenTagCount > 0 ? `
              <span class="__kaelis_expand_trigger" style="padding:4px 10px;border-radius:10px;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ao3-base-size)*0.76);font-weight:700;line-height:1.4;cursor:pointer;">
                +${hiddenTagCount} 个标签 ▾
              </span>
            ` : ""}
          </div>

          <!-- Summary Area -->
          ${summarySectionHtml}

          <!-- Clean Bottom Divider Row (NO shaded box! Stats on left, pill button on right, 1:1 like Image 1!) -->
          <div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--ao3-border);display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:calc(var(--ao3-base-size)*0.78);color:var(--ao3-subtext);">
            <div style="display:flex;align-items:center;flex-wrap:wrap;gap:12px;">
              ${statsParts.join("")}
            </div>
            ${canExpand ? `
              <button type="button" class="__kaelis_expand_trigger" style="flex-shrink:0;padding:5px 13px;border-radius:999px;border:none;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ao3-base-size)*0.76);font-weight:700;cursor:pointer;">
                ${isExpanded ? "收起内容 ▴" : "展开内容 ▾"}
              </button>
            ` : `
              <a href="${workUrl}" style="flex-shrink:0;padding:5px 13px;border-radius:999px;background:var(--ao3-accent-soft);color:var(--ao3-accent);font-size:calc(var(--ao3-base-size)*0.76);font-weight:700;">
                阅读正文 →
              </a>
            `}
          </div>
        `;

        card.querySelectorAll(".__kaelis_expand_trigger").forEach(btn => {
          btn.addEventListener("click", function(e) {
            e.preventDefault();
            e.stopPropagation();
            isExpanded = !isExpanded;
            renderCardContent();
          });
        });

        const sumArea = card.querySelector(".__kaelis_summary_area");
        if (sumArea && canExpand) {
          sumArea.addEventListener("click", function(e) {
            if (e.target && e.target.tagName === "A") return;
            isExpanded = !isExpanded;
            renderCardContent();
          });
        }
      }

      renderCardContent();
    });
  }

  function formatDatesOnPage() {
    const dateEls = document.querySelectorAll("p.datetime, span.datetime, dd.published, dd.status, .news .meta");
    dateEls.forEach(el => {
      const converted = convertDateString(el.textContent || "");
      if (converted && converted !== el.textContent) {
        el.textContent = converted;
      }
    });
  }

  function enhanceWorkMetaBox() {
    const workMeta = document.querySelector("dl.work.meta.group");
    if (workMeta && !workMeta.querySelector("#__ao3_meta_toggle")) {
      const toggleBar = document.createElement("div");
      toggleBar.id = "__ao3_meta_toggle";
      toggleBar.style.cssText = "display:flex;align-items:center;justify-content:space-between;cursor:pointer;font-size:calc(var(--ao3-base-size)*0.82);font-weight:700;color:var(--ao3-accent);";
      toggleBar.innerHTML = `<span>📋 作品标签与统计详情（点击展开）</span><span id="__ao3_meta_arrow">▾</span>`;
      toggleBar.addEventListener("click", () => {
        const open = workMeta.classList.toggle("__ao3_meta_open");
        toggleBar.querySelector("#__ao3_meta_arrow").textContent = open ? "▴" : "▾";
        toggleBar.querySelector("span").textContent = open ? "📋 收起作品标签与统计详情" : "📋 作品标签与统计详情（点击展开）";
      });
      workMeta.prepend(toggleBar);
    }
  }

  function translateDOM() {
    if (!config.zhTranslate || !document.body) return;

    document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(btn => {
      const val = (btn.value || "").trim();
      if (ZH_DICT[val]) btn.value = ZH_DICT[val];
    });

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      const raw = node.nodeValue.trim();
      if (!raw) continue;
      if (ZH_DICT[raw]) {
        node.nodeValue = node.nodeValue.replace(raw, ZH_DICT[raw]);
      } else if (raw.startsWith("You searched for:")) {
        node.nodeValue = raw
          .replace("You searched for:", "当前搜索：")
          .replace("sort by:", "排序：")
          .replace("best match", "最佳匹配")
          .replace("date posted", "发布时间")
          .replace("date updated", "更新时间")
          .replace("word count", "字数")
          .replace("kudos", "点赞数")
          .replace("hits", "点击量")
          .replace("descending", "降序")
          .replace("ascending", "升序");
      } else if (raw.endsWith(" Found")) {
        node.nodeValue = "共找到 " + raw.replace(" Found", "") + " 篇作品";
      } else if (raw.startsWith("Browse fandoms by media")) {
        node.nodeValue = "按分类浏览同人圈，点进感兴趣的分类即可按作品热度筛选：";
      }
    }
  }

  // ==================== CLEAN, UNCLUTTERED PAGE FLIP READER (Fixes Image 4 top overlap & footer wrapping!) ====================
  let pagedState = {
    pages: [],
    currentIndex: 0,
    workTitle: "阅读正文"
  };

  function collectStoryUnits() {
    const workskin = document.getElementById("workskin");
    if (!workskin) return [];
    const units = [];

    const titleEl = workskin.querySelector("h2.title.heading");
    const authorEl = workskin.querySelector("h3.byline.heading");
    if (titleEl) {
      pagedState.workTitle = titleEl.textContent.trim();
      units.push(
        `<div style="margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid var(--ao3-border);">
           <div style="font-size:calc(var(--ao3-base-size)*1.12);font-weight:800;color:var(--ao3-accent);line-height:1.4;">${titleEl.textContent.trim()}</div>
           ${authorEl ? `<div style="font-size:calc(var(--ao3-base-size)*0.78);color:var(--ao3-subtext);margin-top:4px;">作者：${authorEl.textContent.trim()}</div>` : ""}
         </div>`
      );
    }

    const paras = workskin.querySelectorAll("#chapters .userstuff p, #chapters .userstuff h3, div.userstuff p");
    if (paras.length > 0) {
      paras.forEach(p => {
        const text = (p.textContent || "").trim();
        if (!text) return;
        // Split paragraphs over 95 chars into smaller sentence chunks so pages fill evenly to the bottom without large empty gaps!
        if (text.length > 95) {
          const sentences = text.match(/[^。！？!?]+[。！？!?”’”]*/g) || [text];
          let chunk = "";
          sentences.forEach(s => {
            if ((chunk + s).length > 85 && chunk.length > 0) {
              units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${chunk}</p>`);
              chunk = s;
            } else {
              chunk += s;
            }
          });
          if (chunk) {
            units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${chunk}</p>`);
          }
        } else {
          units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${p.innerHTML}</p>`);
        }
      });
    } else {
      const userstuff = workskin.querySelector("#chapters .userstuff, div.userstuff");
      if (userstuff) {
        const lines = userstuff.innerHTML.split(/<br\s*\/?>/i);
        lines.forEach(l => {
          const clean = l.trim();
          if (clean) {
            units.push(`<p style="margin:0 0 0.85em 0;line-height:1.85;text-align:justify;">${clean}</p>`);
          }
        });
      }
    }
    return units;
  }

  function buildDiscretePages() {
    const readerOverlay = document.getElementById("__ao3_paged_reader");
    const workskin = document.getElementById("workskin");

    if (config.readingMode !== "page" || !workskin) {
      document.body.classList.remove("__ao3_paged_active");
      if (readerOverlay) readerOverlay.style.display = "none";
      document.body.style.overflow = "";
      return;
    }

    // Activate paged mode class so #__ao3_custom_header and #main are completely hidden (no overlap!)
    document.body.classList.add("__ao3_paged_active");
    document.body.style.overflow = "hidden";

    let overlay = readerOverlay;
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "__ao3_paged_reader";
      overlay.style.cssText = "position:fixed;inset:0;z-index:9990;display:flex;flex-direction:column;padding:10px 12px 12px 12px;box-sizing:border-box;user-select:none;";
      overlay.innerHTML = `
        <!-- Minimalist, Single-Row Top Bar (Fixed 13px UI font so it NEVER wraps or looks messy!) -->
        <div style="height:40px;display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;flex-shrink:0;">
          <button id="__ao3_paged_back" style="height:34px;padding:0 12px;border-radius:10px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:12.5px !important;font-weight:700;white-space:nowrap;flex-shrink:0;">
            ← 返回
          </button>
          <div id="__ao3_paged_title" style="flex:1;min-width:0;text-align:center;font-size:13.5px !important;font-weight:700;color:var(--ao3-text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 4px;">
            阅读正文
          </div>
          <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
            <button id="__ao3_paged_exit" style="height:34px;padding:0 12px;border-radius:10px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:12.5px !important;font-weight:700;white-space:nowrap;">
              滑动模式
            </button>
            <button id="__ao3_paged_settings" style="width:34px;height:34px;padding:0;border-radius:10px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:13px !important;font-weight:800;display:flex;align-items:center;justify-content:center;">
              Aa
            </button>
          </div>
        </div>

        <!-- Clean Story Page Card -->
        <div style="flex:1;min-height:0;background:var(--ao3-card-bg);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid var(--ao3-border);border-radius:22px;padding:18px 18px 10px 18px;display:flex;flex-direction:column;justify-content:space-between;position:relative;box-sizing:border-box;box-shadow:0 8px 26px rgba(42,32,68,0.05);">
          <div id="__ao3_page_box" style="flex:1;min-height:0;overflow:hidden;font-family:var(--ao3-font);font-size:var(--ao3-base-size);color:var(--ao3-text);"></div>

          <!-- Left/Right Instant Tap Zones -->
          <div style="position:absolute;inset:0 0 42px 0;display:flex;z-index:5;">
            <div id="__ao3_Zone_Prev" style="width:38%;height:100%;cursor:pointer;"></div>
            <div id="__ao3_Zone_Mid" style="width:24%;height:100%;"></div>
            <div id="__ao3_Zone_Next" style="width:38%;height:100%;cursor:pointer;"></div>
          </div>

          <!-- Clean Single-Line Footer (Fixed 12px UI font & nowrap so it NEVER wraps onto 2 lines!) -->
          <div style="height:34px;padding-top:8px;margin-top:4px;border-top:1px solid var(--ao3-border);display:flex;align-items:center;justify-content:space-between;font-size:12px !important;color:var(--ao3-subtext);flex-shrink:0;position:relative;z-index:10;white-space:nowrap;">
            <span id="__ao3_paged_indicator" style="font-size:12px !important;font-weight:700;white-space:nowrap;">1 / 1 页</span>
            <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
              <button id="__ao3_btn_p_prev" style="padding:4px 12px;border-radius:999px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:12px !important;font-weight:600;white-space:nowrap;">上一页</button>
              <button id="__ao3_btn_p_next" style="padding:4px 12px;border-radius:999px;border:1px solid var(--ao3-border);background:var(--ao3-pill-bg);color:var(--ao3-text);font-size:12px !important;font-weight:600;white-space:nowrap;">下一页</button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(overlay);

      overlay.querySelector("#__ao3_paged_back").addEventListener("click", () => {
        if (window.history.length > 1) {
          window.history.back();
        } else {
          window.location.href = "/";
        }
      });
      overlay.querySelector("#__ao3_paged_exit").addEventListener("click", () => {
        config.readingMode = "scroll";
        const mb = document.getElementById("__ao3_mode_btn");
        if (mb) mb.textContent = "滑动模式";
        saveConfig();
        applyAll();
      });
      overlay.querySelector("#__ao3_paged_settings").addEventListener("click", () => {
        const modal = document.getElementById("__ao3_settings_modal");
        if (modal) modal.style.display = "flex";
      });
      overlay.querySelector("#__ao3_Zone_Prev").addEventListener("click", () => window.__ao3TurnPage("prev"));
      overlay.querySelector("#__ao3_Zone_Next").addEventListener("click", () => window.__ao3TurnPage("next"));
      overlay.querySelector("#__ao3_btn_p_prev").addEventListener("click", () => window.__ao3TurnPage("prev"));
      overlay.querySelector("#__ao3_btn_p_next").addEventListener("click", () => window.__ao3TurnPage("next"));
    }

    overlay.style.display = "flex";

    const pageBox = overlay.querySelector("#__ao3_page_box");
    const maxH = pageBox.clientHeight || (window.innerHeight - 130);
    const units = collectStoryUnits();

    const titleNode = overlay.querySelector("#__ao3_paged_title");
    if (titleNode) titleNode.textContent = pagedState.workTitle || "阅读正文";

    const pages = [];
    pageBox.innerHTML = "";
    let currentHtml = "";

    for (let i = 0; i < units.length; i++) {
      const u = units[i];
      pageBox.innerHTML = currentHtml + u;
      if (pageBox.scrollHeight > maxH && currentHtml !== "") {
        pages.push(currentHtml);
        currentHtml = u;
      } else {
        currentHtml += u;
      }
    }
    if (currentHtml) pages.push(currentHtml);
    if (pages.length === 0) pages.push("<p>暂无正文内容</p>");

    pagedState.pages = pages;
    if (pagedState.currentIndex >= pages.length) pagedState.currentIndex = pages.length - 1;
    if (pagedState.currentIndex < 0) pagedState.currentIndex = 0;

    renderCurrentDiscretePage();
  }

  function renderCurrentDiscretePage() {
    const overlay = document.getElementById("__ao3_paged_reader");
    if (!overlay || overlay.style.display === "none") return;
    const pageBox = overlay.querySelector("#__ao3_page_box");
    const indicator = overlay.querySelector("#__ao3_paged_indicator");
    const total = pagedState.pages.length;
    const idx = pagedState.currentIndex;
    pageBox.innerHTML = pagedState.pages[idx] || "";
    indicator.textContent = `第 ${idx + 1} / ${total} 页`;
  }

  window.__ao3TurnPage = function(dir) {
    if (config.readingMode === "page" && document.getElementById("workskin")) {
      const nextIdx = pagedState.currentIndex + (dir === "next" ? 1 : -1);
      if (nextIdx >= 0 && nextIdx < pagedState.pages.length) {
        pagedState.currentIndex = nextIdx;
        renderCurrentDiscretePage();
      } else if (nextIdx >= pagedState.pages.length) {
        const nextChap = document.querySelector("li.chapter.next a, a[rel='next']");
        if (nextChap && nextChap.href) {
          window.location.href = nextChap.href;
        }
      }
    } else {
      const step = Math.floor(window.innerHeight * 0.82);
      window.scrollTo(0, Math.max(0, window.scrollY + (dir === "next" ? step : -step)));
    }
  };

  window.__ao3VolumeKey = function(dir) {
    window.__ao3TurnPage(dir);
  };

  function buildSettingsModal() {
    if (!document.body || document.getElementById("__ao3_settings_modal")) return;
    const modal = document.createElement("div");
    modal.id = "__ao3_settings_modal";
    modal.style.cssText = "position:fixed;inset:0;z-index:100000;background:rgba(20,16,28,0.45);display:none;align-items:flex-end;justify-content:center;";
    modal.innerHTML = `
      <div style="width:100%;max-width:480px;max-height:88vh;overflow-y:auto;background:#fbfafc;border-radius:28px 28px 0 0;padding:22px 20px 26px;color:#2c2638;box-shadow:0 -8px 32px rgba(0,0,0,0.18);font-family:sans-serif;box-sizing:border-box;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <div style="font-size:20px;font-weight:800;">阅读设置</div>
          <button id="__ao3_close_modal" style="width:36px;height:36px;padding:0;border-radius:12px;border:1px solid #e6e2ec;background:#fff;font-size:16px;color:#555;">✕</button>
        </div>
        <div style="font-size:12px;color:#8c849c;margin-bottom:16px;">全局字号与字体在首页、搜索卡片及正文阅读中同步缩放。</div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">全局字号 • <span id="__ao3_fs_val">${config.fontSize}</span> px</div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
          <button id="__ao3_fs_dec" style="width:44px;height:38px;padding:0;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A-</button>
          <input id="__ao3_fs_range" type="range" min="13" max="24" value="${config.fontSize}" style="flex:1;" />
          <button id="__ao3_fs_inc" style="width:44px;height:38px;padding:0;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-weight:700;color:#2c2638;">A+</button>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:6px;">全局字体</div>
        <select id="__ao3_font_sel" style="width:100%;padding:11px 14px;border-radius:14px;border:1px solid #e2dde9;background:#fff;font-size:14px;color:#2c2638;margin-bottom:14px;">
          <option value="system">系统默认字体（默认）</option>
          <option value="song">飞花宋体 / 思源宋体</option>
          <option value="kai">霞鹜文楷 / 传统楷体</option>
          <option value="hei">柔和黑体 / 无衬线</option>
        </select>

        <div id="__ao3_preview_box" style="padding:16px;border-radius:16px;border:1px solid #e2dde9;margin-bottom:16px;line-height:1.75;">
          浮光落在纸页上。他放下书，轻声说：<br>“不着急，慢慢读。”
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:8px;">阅读翻页方式</div>
        <div style="display:flex;gap:8px;margin-bottom:16px;">
          <button id="__ao3_set_scroll" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">上下滑动</button>
          <button id="__ao3_set_page" style="flex:1;padding:10px;border-radius:12px;border:1px solid #dcd6e8;background:#fff;font-size:13px;font-weight:700;color:#2c2638;">左右翻页(无动画)</button>
        </div>

        <div style="font-size:14px;font-weight:700;margin-bottom:10px;">背景颜色与相册壁纸</div>
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:14px;flex-wrap:wrap;" id="__ao3_preset_row"></div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">色相</span>
          <input id="__ao3_hue" type="range" min="0" max="360" value="${config.hue}" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">浓淡</span>
          <input id="__ao3_sat" type="range" min="0" max="80" value="${config.sat}" style="flex:1;" />
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;font-size:13px;color:#6e667e;">
          <span style="width:36px;">明暗</span>
          <input id="__ao3_light" type="range" min="12" max="97" value="${config.light}" style="flex:1;" />
        </div>

        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;font-size:13px;color:#6e667e;">
          <span style="width:72px;">背景透明度</span>
          <input id="__ao3_opacity" type="range" min="20" max="100" value="${config.bgOpacity}" style="flex:1;" />
          <span id="__ao3_op_val" style="width:38px;text-align:right;">${config.bgOpacity}%</span>
        </div>

        <div style="display:flex;gap:10px;margin-bottom:18px;">
          <label style="flex:1;padding:11px;border-radius:12px;border:1px dashed #b8aed0;background:#f5f2fa;color:#524668;font-size:13px;font-weight:700;text-align:center;cursor:pointer;">
            🖼️ 选择手机相册背景图
            <input id="__ao3_bg_file" type="file" accept="image/*" style="display:none;" />
          </label>
          <button id="__ao3_clear_bg" style="padding:11px 14px;border-radius:12px;border:1px solid #e2dde9;background:#fff;font-size:13px;color:#666;">清除背景图</button>
        </div>

        <div style="display:flex;gap:12px;">
          <button id="__ao3_reset_btn" style="flex:1;padding:13px;border-radius:14px;border:1px solid #dcd6e8;background:#fff;font-size:15px;font-weight:700;color:#554d66;">恢复默认</button>
          <button id="__ao3_save_btn" style="flex:1;padding:13px;border-radius:14px;border:none;background:#3b3746;font-size:15px;font-weight:700;color:#fff;">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    const presetRow = modal.querySelector("#__ao3_preset_row");
    PRESETS.forEach(p => {
      const dot = document.createElement("div");
      dot.className = "__ao3_color_dot";
      dot.title = p.name;
      dot.style.background = `hsl(${p.h},${p.s}%,${p.l}%)`;
      dot.style.border = "2px solid #b5abc9";
      dot.addEventListener("click", () => {
        config.hue = p.h;
        config.sat = p.s;
        config.light = p.l;
        modal.querySelector("#__ao3_hue").value = p.h;
        modal.querySelector("#__ao3_sat").value = p.s;
        modal.querySelector("#__ao3_light").value = p.l;
        applyAll();
        syncPreview();
      });
      presetRow.appendChild(dot);
    });

    function syncPreview() {
      const box = modal.querySelector("#__ao3_preview_box");
      box.style.fontSize = config.fontSize + "px";
      box.style.fontFamily = getFontStack(config.fontFamily);
      box.style.background = `hsl(${config.hue}, ${config.sat}%, ${config.light}%)`;
      box.style.color = config.light < 36 ? "#f2eef8" : "#2c2638";
    }

    modal.querySelector("#__ao3_close_modal").addEventListener("click", () => modal.style.display = "none");
    modal.querySelector("#__ao3_save_btn").addEventListener("click", () => {
      saveConfig();
      modal.style.display = "none";
    });
    modal.querySelector("#__ao3_reset_btn").addEventListener("click", () => {
      config = Object.assign({}, DEFAULT_CONFIG);
      saveConfig();
      applyAll();
      syncPreview();
    });

    modal.querySelector("#__ao3_fs_range").addEventListener("input", e => {
      config.fontSize = parseInt(e.target.value, 10);
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_fs_dec").addEventListener("click", () => {
      config.fontSize = Math.max(13, config.fontSize - 1);
      modal.querySelector("#__ao3_fs_range").value = config.fontSize;
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_fs_inc").addEventListener("click", () => {
      config.fontSize = Math.min(24, config.fontSize + 1);
      modal.querySelector("#__ao3_fs_range").value = config.fontSize;
      modal.querySelector("#__ao3_fs_val").textContent = config.fontSize;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_font_sel").value = config.fontFamily;
    modal.querySelector("#__ao3_font_sel").addEventListener("change", e => {
      config.fontFamily = e.target.value;
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_hue").addEventListener("input", e => {
      config.hue = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_sat").addEventListener("input", e => {
      config.sat = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_light").addEventListener("input", e => {
      config.light = parseInt(e.target.value, 10);
      applyAll();
      syncPreview();
    });
    modal.querySelector("#__ao3_opacity").addEventListener("input", e => {
      config.bgOpacity = parseInt(e.target.value, 10);
      modal.querySelector("#__ao3_op_val").textContent = config.bgOpacity + "%";
      applyAll();
    });
    modal.querySelector("#__ao3_set_scroll").addEventListener("click", () => {
      config.readingMode = "scroll";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "滑动模式";
      saveConfig();
      applyAll();
    });
    modal.querySelector("#__ao3_set_page").addEventListener("click", () => {
      config.readingMode = "page";
      const mb = document.getElementById("__ao3_mode_btn");
      if (mb) mb.textContent = "翻页模式";
      saveConfig();
      applyAll();
    });
    modal.querySelector("#__ao3_bg_file").addEventListener("change", e => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function(ev) {
        config.bgImage = ev.target.result;
        saveConfig();
        applyAll();
      };
      reader.readAsDataURL(file);
    });
    modal.querySelector("#__ao3_clear_bg").addEventListener("click", () => {
      config.bgImage = "";
      saveConfig();
      applyAll();
    });

    syncPreview();
  }

  function applyAll() {
    ensureViewportMeta();
    injectStyles();
    if (!document.body) return;
    ensureBgLayers();
    buildCustomHeader();
    formatDatesOnPage();
    rebuildBlurbCardsToMatchImage1();
    enhanceWorkMetaBox();
    translateDOM();
    buildSettingsModal();
    buildDiscretePages();
  }

  window.__ao3ApplyAll = applyAll;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyAll);
  } else {
    applyAll();
  }
})();
